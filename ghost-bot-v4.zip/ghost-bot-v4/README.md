# Ghost Bot

Bot de loja para Discord com comandos de barra e prefixo, catálogo JSON, vitrines, carrinhos privados, pagamento PIX, entrega automática/manual, suporte, proteções e agente com aprovação do dono.

## Instalação

Requer Python 3.10 ou posterior.

1. Instale as dependências:

   ```bash
   python -m pip install -r requirements.txt
   ```

2. Preencha o `.env` com o token do bot e os IDs necessários. Para uma instalação nova, use `.env.example` como modelo.
3. Inicie:

   ```bash
   python main.py
   ```

Ative os intents de membros e conteúdo de mensagens no portal do Discord. O cargo do bot precisa estar acima dos cargos que ele administra. Uma instalação deve usar apenas um processo por banco SQLite.

Os caminhos são calculados a partir da pasta do projeto, e não do diretório atual do terminal. O `.env` fica na raiz; o banco SQLite e o diário ficam em `data/` (`data/banco.db` e `data/diario.jsonl`). Para usar outro local, defina `DB_PATH` ou `DIARIO_PATH`; caminhos relativos continuam partindo da raiz do projeto.

## Dados incluídos

Este pacote mantém o `.env`, o banco SQLite e seus arquivos auxiliares em `data/`, o diário, os backups existentes, o catálogo e os assets. Faça uma cópia antes de atualizar. Não compartilhe o ZIP: o `.env`, o banco, o estoque e o diário podem conter credenciais e dados privados.

## Backup do servidor

Backups novos guardam configurações gerais capturadas, permissões, cargos, canais, emojis, membros e todo o histórico de mensagens que o bot consegue ler nos canais e threads. A restauração remove extras e preserva o trecho inicial intacto do histórico. A partir de uma mensagem ausente/alterada, reconstrói o restante em ordem usando webhooks, exibindo apelido, avatar disponível e horário originais. Reenvios confirmados ficam registrados para evitar duplicações em retomadas. Também remove canais, cargos e emojis extras que o bot consegue administrar.

O bot cancela a criação se não conseguir ler os históricos e membros necessários. Backups anteriores a esse formato ficam guardados, mas não podem ser restaurados como sincronização exata porque não contêm o snapshot completo de mensagens. Uma réplica visual não é o registro nativo original: mensagens republicadas recebem novos IDs e são enviadas pelo webhook; anexos dependem de links ainda válidos. Itens gerenciados por integrações, membros que já saíram, recursos que a API não expõe e certas configurações exclusivas do dono não podem ser copiados integralmente. Acesso, hierarquia e limites da API também podem impedir alterações. Faça o teste em um servidor separado antes de depender do backup.

Antes de restaurar, crie um backup atual e teste em um servidor separado. Para restaurar, o bot precisa das permissões de gerenciar servidor, canais, cargos, emojis/figurinhas e membros, conforme as funções usadas.


## Anti-raid desta versão

A proteção usa um incidente persistente no SQLite. A sequência é: registrar o incidente e fixar o backup anterior, neutralizar os responsáveis, pausar convites, conter novas alterações, esperar **60 segundos sem atividade**, restaurar e só então liberar. O intervalo reinicia com novas ações. Falha de hierarquia, punição, leitura ou restauração mantém a proteção; não há liberação automática por um timer cego. Reiniciar o processo retoma a contenção.

- Mensagens novas e editadas de todos, inclusive deste bot e de outros bots/webhooks, são apagadas durante a contenção; só o dono real do servidor fica livre. Na fase de restauração, apenas os webhooks pertencentes a este bot e registrados pelo restaurador podem repor o histórico. Comandos de outros membros ficam suspensos.
- Novos canais são apagados; exclusões de canais do backup disparam reposição, depois da tentativa de neutralizar o autor. Tópicos, webhooks, cargos, permissões, bans/expulsões, convites, emojis, figurinhas, integrações, regras de AutoMod, eventos agendados, soundboard, reações e entradas em massa têm detecção. Eventos de auditoria do próprio restaurador não viram ataques contra ele mesmo.
- Uma ação estrutural suspeita feita por bot externo (criar/editar/apagar canais, tópicos, cargos, webhooks ou configurações) inicia contenção na primeira ocorrência e tenta banir o bot. O usuário identificado na auditoria como quem o adicionou é colocado em quarentena, perde os cargos removíveis e fica bloqueado; o usuário que executou um comando de raid também é punido quando o Discord informa o autor. Spam por bot também aciona a sanção. Ações destrutivas humanas e reincidência levam à tentativa de banimento; spam humano começa com retirada de cargos, timeout de 28 dias e bloqueio individual. Hierarquia insuficiente é registrada como falha, nunca como punição aplicada. Administradores e equipe não têm imunidade; só o dono real do servidor é excluído das sanções automáticas.
- A relação bot → quem o adicionou usa o alvo exato da auditoria. A relação membro → criador de convite é inferida pela diferença de usos observada na entrada. Entradas simultâneas, convites de uso único desaparecidos, vanity links e falta de acesso podem deixá-la indeterminada. O criador não necessariamente foi quem compartilhou o link. O registro deixa isso explícito.
- Revoga convites dos responsáveis e do criador ligado à entrada. Bane membros associados sem ambiguidade de contador a esses convites e que entraram desde as **3 horas anteriores** ao início do incidente; não expande uma cadeia ilimitada. Quem convidou alguém não é punido apenas por essa associação, mas os convites relacionados são revogados. O histórico começa quando esta versão passa a observar entradas; não é possível reconstruir retroativamente quem usou cada convite antes disso.
- As sanções sobrevivem à restauração: cargos do snapshot não voltam aos alvos. Logs ficam no diário durante o bloqueio; a conclusão e as cadeias de entrada são enviadas ao canal de logs após a liberação.

Comandos do dono configurado, também utilizáveis por DM: `>raidstatus` mostra fase e pendências; `>raidretomar` tenta novamente após corrigir a causa da falha; `>raidliberar ID` revisa uma sanção depois do incidente e não concede cargos antigos automaticamente. O prefixo segue a configuração do bot. `>reverter` não contorna uma contenção ativa.

A pausa tenta primeiro o recurso persistente do Discord e, se indisponível, usa a pausa temporária de 24h renovada durante a execução. O bot precisa permanecer online; perder o token, ser expulso, perder permissões ou ficar abaixo do agressor na hierarquia impede a atuação. A API aplica limites de requisições: apagar mensagens e reconstruir canais não é instantâneo.

**Há limites que a API do Discord impõe à réplica.** O bot salva e reconcilia os campos estruturais disponíveis, incluindo configuração do servidor, canais e categorias, cargos e permissões, threads, membros presentes, bans, convites, webhooks, figurinhas, AutoMod e eventos agendados. Convites recriados recebem códigos novos; webhooks recriados recebem IDs/tokens novos; estados de RSVP e objetos geridos por integrações não podem ser reproduzidos como os originais. Mensagens reconstruídas preservam visualmente autor, avatar disponível e horário, mas recebem IDs novos; anexos dependem de URLs ainda válidas. Permissões, hierarquia e limites da API podem impedir ações. Faça o teste em um servidor separado antes de depender da recuperação automática.

Validação local desta revisão: 61 testes automatizados com banco temporário e Discord simulado, compilação e checagem de nomes indefinidos. Nenhuma ação foi executada no servidor real. Testes e ferramentas de desenvolvimento não fazem parte do ZIP.
