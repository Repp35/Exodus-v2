"""Conexão SQLite e schema. Mantém as mesmas tabelas do banco legado."""

import logging
import os
import sqlite3
from contextlib import contextmanager
from typing import Iterator

from ..core import diario
from ..config import settings

log = logging.getLogger("db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS raid_entradas (
    id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id TEXT NOT NULL, user_id TEXT NOT NULL,
    entrou REAL NOT NULL, convite TEXT, criador TEXT
);
CREATE INDEX IF NOT EXISTS raid_entrada_user ON raid_entradas(guild_id,user_id,entrou);
CREATE INDEX IF NOT EXISTS raid_entrada_tempo ON raid_entradas(guild_id,entrou);

CREATE TABLE IF NOT EXISTS pedido_entregas (
    pedido_id INTEGER NOT NULL REFERENCES pedidos(id), estoque_id INTEGER NOT NULL, kind TEXT NOT NULL,
    status TEXT NOT NULL, PRIMARY KEY(pedido_id, estoque_id, kind)
);
CREATE TABLE IF NOT EXISTS bots_adicionados (
    bot_id TEXT PRIMARY KEY,
    adicionado_por TEXT NOT NULL,
    adicionado_em TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS webhooks_criadores (
    webhook_id TEXT PRIMARY KEY,
    criador_id TEXT NOT NULL,
    criado_em TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS estoque (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    produto_key TEXT NOT NULL,
    email TEXT NOT NULL,
    senha TEXT NOT NULL,
    extra TEXT,
    vendido INTEGER NOT NULL DEFAULT 0,
    reservado INTEGER NOT NULL DEFAULT 0,
    reservado_em TEXT,
    reservado_por TEXT,
    criado_em TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS estoque_links (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    produto_key TEXT NOT NULL,
    link TEXT NOT NULL,
    vendido INTEGER NOT NULL DEFAULT 0,
    reservado INTEGER NOT NULL DEFAULT 0,
    reservado_em TEXT,
    reservado_por TEXT,
    criado_em TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS pedidos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    payment_id TEXT,
    produto_key TEXT NOT NULL,
    valor REAL NOT NULL,
    quantidade INTEGER NOT NULL DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'pending',
    discord_user_id TEXT NOT NULL,
    thread_id TEXT,
    estoque_id INTEGER,
    criado_em TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS precos (
    produto_key TEXT PRIMARY KEY,
    preco REAL NOT NULL,
    ativo INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS setup_messages (
    tipo TEXT PRIMARY KEY,
    channel_id TEXT NOT NULL,
    message_id TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS config (
    chave TEXT PRIMARY KEY,
    valor TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS threads_ativas (
    thread_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    tipo TEXT NOT NULL,
    produto_key TEXT,
    entrega_manual INTEGER NOT NULL DEFAULT 0,
    criado_em TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS banidos (
    user_id TEXT PRIMARY KEY,
    motivo TEXT,
    banido_em TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS admins (
    user_id TEXT PRIMARY KEY,
    adicionado_por TEXT NOT NULL,
    adicionado_em TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS staff (
    user_id TEXT PRIMARY KEY,
    adicionado_por TEXT NOT NULL,
    adicionado_em TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS canais_snapshot (
    channel_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    category_id TEXT,
    topic TEXT,
    position INTEGER,
    atualizado_em TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS fechamentos_agendados (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    thread_id TEXT NOT NULL,
    fechar_em TEXT NOT NULL,
    motivo TEXT,
    criado_em TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS entregas_confirmadas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    discord_user_id TEXT NOT NULL,
    estoque_id INTEGER NOT NULL,
    produto_key TEXT NOT NULL,
    entregue_em TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS restock_pedidos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    produto_key TEXT NOT NULL,
    thread_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pendente',
    criado_em TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_restock_pedido_unico
    ON restock_pedidos (user_id, produto_key) WHERE status = 'pendente';
CREATE TABLE IF NOT EXISTS restock_interessados (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    produto_key TEXT NOT NULL,
    preferencia TEXT NOT NULL DEFAULT 'notificar',
    criado_em TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS cupons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL UNIQUE COLLATE NOCASE,
    desconto_pct INTEGER NOT NULL CHECK (desconto_pct BETWEEN 1 AND 99),
    primeira_compra INTEGER NOT NULL DEFAULT 0,
    min_produto REAL NOT NULL DEFAULT 0.0,
    limite_usos INTEGER,
    usos_atuais INTEGER NOT NULL DEFAULT 0,
    validade TEXT,
    ativo INTEGER NOT NULL DEFAULT 1,
    criado_em TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS cupons_uso (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cupom_id INTEGER NOT NULL REFERENCES cupons(id),
    user_id TEXT NOT NULL,
    pedido_id INTEGER,
    usado_em TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS avisos_estoque (
    user_id TEXT NOT NULL,
    produto_key TEXT NOT NULL,
    criado_em TEXT NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (user_id, produto_key)
);
CREATE TABLE IF NOT EXISTS produtos_anunciados (
    produto_key TEXT PRIMARY KEY,
    anunciado_em TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS catalogo_loja (
    tipo TEXT NOT NULL,
    id TEXT NOT NULL,
    dados TEXT NOT NULL,
    atualizado_por TEXT NOT NULL,
    atualizado_em TEXT NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (tipo, id)
);
"""

INDEXES = """
CREATE INDEX IF NOT EXISTS idx_entregas_cliente ON entregas_confirmadas(discord_user_id, produto_key, estoque_id);
CREATE INDEX IF NOT EXISTS idx_cupom_uso ON cupons_uso(cupom_id, user_id);
CREATE INDEX IF NOT EXISTS idx_cupom_pedido ON cupons_uso(pedido_id);
CREATE INDEX IF NOT EXISTS idx_estoque_disponivel ON estoque (produto_key, vendido, reservado);
CREATE INDEX IF NOT EXISTS idx_links_disponivel ON estoque_links (produto_key, vendido, reservado);
CREATE INDEX IF NOT EXISTS idx_pedidos_payment ON pedidos (payment_id);
CREATE INDEX IF NOT EXISTS idx_pedidos_status_thread ON pedidos (status, thread_id);
CREATE INDEX IF NOT EXISTS idx_pedidos_user_status ON pedidos (discord_user_id, status);
CREATE INDEX IF NOT EXISTS idx_threads_user_tipo ON threads_ativas (user_id, tipo, produto_key);
"""

# Colunas que bancos antigos podem não ter.
COLUMN_MIGRATIONS = {
    "pedidos": {
        "quantidade": "INTEGER NOT NULL DEFAULT 1",
        "checkout_key": "TEXT",
        "checkout_descricao": "TEXT",
        "checkout_email": "TEXT",
        "entrega_status": "TEXT NOT NULL DEFAULT 'legacy'",
        "venda_anunciada": "INTEGER NOT NULL DEFAULT 0",
        "pix_publicado": "INTEGER NOT NULL DEFAULT 0",
    },
    "estoque": {"extra": "TEXT"},
    "estoque_links": {"extra": "TEXT"},
    "canais_snapshot": {"permissoes": "TEXT"},
    "threads_ativas": {
        "entrega_manual": "INTEGER NOT NULL DEFAULT 0",
        "ticket_escolha": "TEXT",
        "assumido_por": "TEXT",
        "quantidade": "INTEGER NOT NULL DEFAULT 1",
    },
}


_conn: sqlite3.Connection | None = None
_conn_path: str | None = None
_depth = 0


_escritas: list[str] = []  # escritas da transação atual; só vão ao diário após o commit


def _ao_executar(sql: str) -> None:
    comando = sql.strip()
    if comando.upper().startswith(("INSERT", "UPDATE", "DELETE", "REPLACE")):
        _escritas.append(comando)


def _connect() -> sqlite3.Connection:
    """Conexão única reutilizada: o bot usa um só event loop, então não há acesso concorrente."""
    global _conn, _conn_path
    if _conn is not None and _conn_path != settings.DB_PATH:
        close()
    if _conn is None:
        if settings.DB_PATH != ":memory:":
            os.makedirs(os.path.dirname(settings.DB_PATH), mode=0o700, exist_ok=True)
        conn = sqlite3.connect(settings.DB_PATH, timeout=10, check_same_thread=False)
        if settings.DB_PATH != ":memory:":
            os.chmod(settings.DB_PATH, 0o600)
        conn.row_factory = sqlite3.Row
        conn.set_trace_callback(_ao_executar)
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA synchronous = NORMAL")
        conn.execute("PRAGMA busy_timeout = 10000")
        _conn, _conn_path = conn, settings.DB_PATH
    return _conn


def close() -> None:
    global _conn, _conn_path, _depth
    _escritas.clear()
    if _conn is not None:
        _conn.close()
    _conn, _conn_path, _depth = None, None, 0


@contextmanager
def connection() -> Iterator[sqlite3.Connection]:
    """Só o bloco mais externo faz commit ou rollback, então chamadas aninhadas são seguras."""
    global _depth
    conn = _connect()
    savepoint = f"ghost_nested_{_depth}" if _depth else None
    offset = len(_escritas)
    if savepoint:
        if not conn.in_transaction:
            conn.execute("BEGIN")
        conn.execute(f"SAVEPOINT {savepoint}")
    _depth += 1
    try:
        yield conn
    except BaseException:
        if savepoint:
            conn.execute(f"ROLLBACK TO {savepoint}")
            conn.execute(f"RELEASE {savepoint}")
            del _escritas[offset:]
        else:
            conn.rollback()
            _escritas.clear()
        raise
    else:
        if savepoint:
            conn.execute(f"RELEASE {savepoint}")
        if _depth == 1:
            try:
                conn.commit()
            except BaseException:
                conn.rollback()
                _escritas.clear()
                raise
            confirmadas = list(_escritas)
            _escritas.clear()
            diario.escritas(confirmadas)
    finally:
        _depth -= 1


def _existing_columns(conn: sqlite3.Connection, table: str) -> set[str]:
    return {row["name"] for row in conn.execute(f"PRAGMA table_info({table})")}


def init_db() -> None:
    with connection() as conn:
        conn.executescript(SCHEMA)
        for table, columns in COLUMN_MIGRATIONS.items():
            existing = _existing_columns(conn, table)
            for name, decl in columns.items():
                if name not in existing:
                    conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {decl}")
                    log.info("coluna adicionada: %s.%s", table, name)
        for table in ("estoque", "estoque_links"):
            existing = _existing_columns(conn, table)
            for name, decl in (
                ("reservado", "INTEGER NOT NULL DEFAULT 0"),
                ("reservado_em", "TEXT"),
                ("reservado_por", "TEXT"),
            ):
                if name not in existing:
                    conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {decl}")
        conn.executescript(INDEXES)
        _migrar_avisos(conn)
    log.info("banco pronto: %s", settings.DB_PATH)


def _migrar_avisos(conn: sqlite3.Connection) -> None:
    """Uma única vez: leva as inscrições antigas de restock para a tabela de avisos."""
    if conn.execute("SELECT 1 FROM config WHERE chave='migracao_avisos'").fetchone():
        return
    conn.execute(
        "INSERT OR IGNORE INTO avisos_estoque (user_id, produto_key) "
        "SELECT user_id, produto_key FROM restock_interessados WHERE preferencia='notificar'"
    )
    conn.execute("INSERT INTO config (chave, valor) VALUES ('migracao_avisos', '1')")
