"""Configurações do bot. Segredos e IDs do servidor vêm do ambiente (.env); padrões ficam em config.json."""

import json
import os
from pathlib import Path

from dotenv import load_dotenv

# O pacote fica em ``ghost/``; dados de execução e o .env ficam na raiz do
# projeto, ao lado de main.py. Não dependa do diretório de onde o comando foi
# executado (systemd, Docker e painéis costumam usar outro cwd).
PACKAGE_DIR = Path(__file__).resolve().parent.parent
BASE_DIR = PACKAGE_DIR.parent
load_dotenv(BASE_DIR / ".env")
_CFG = json.loads(Path(__file__).with_name("config.json").read_text(encoding="utf-8"))


def _env_int(name: str, default: int = 0) -> int:
    valor = os.getenv(name, "").strip()
    return int(valor) if valor.isdigit() else default


# Segredos e identificadores sensíveis: sempre do ambiente (.env), nunca no código.
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
# Ghost Agent: provedor gratuito (groq, openrouter, gemini ou custom). A chave é do provedor escolhido.
AGENT_PROVIDER = os.getenv("AGENT_PROVIDER", "groq").strip().lower() or "groq"
AGENT_API_KEY = os.getenv("AGENT_API_KEY", "").strip()
AGENT_MODEL = os.getenv("AGENT_MODEL", "").strip()  # vazio = modelo padrão do provedor
AGENT_BASE_URL = os.getenv("AGENT_BASE_URL", "").strip()  # só para AGENT_PROVIDER=custom
# O nome documentado é AGENT_CHANNEL_ID; AGENT_CANAL_ID era usado por versões antigas.
AGENT_CANAL_ID = _env_int("AGENT_CHANNEL_ID") or _env_int("AGENT_CANAL_ID")
MP_ACCESS_TOKEN = os.getenv("MP_ACCESS_TOKEN", "")
PAYER_EMAIL = os.getenv("PAYER_EMAIL", "pagador@ghost.com")


def _env_path(name: str, default: Path) -> str:
    """Retorna caminho absoluto; caminhos relativos são relativos ao projeto."""
    valor = os.getenv(name, "").strip()
    if not valor:
        return str(default)
    if valor == ":memory:":
        return valor
    caminho = Path(valor).expanduser()
    return str(caminho if caminho.is_absolute() else BASE_DIR / caminho)


DB_PATH = _env_path("DB_PATH", BASE_DIR / "data" / "banco.db")
DIARIO_ARQUIVO = _CFG["diario"]["arquivo"]
ADMIN_ID = _env_int("ADMIN_ID")
GUILD_ID = _env_int("GUILD_ID")

PREFIX = _CFG["prefixo"]
NOME_LOJA_PADRAO = _CFG["nome_loja_padrao"]

SALES_CHANNEL_ID = _env_int("SALES_CHANNEL_ID")
LOGS_CHANNEL_ID = _env_int("LOGS_CHANNEL_ID")
FA_CHANNEL_ID = _env_int("FA_CHANNEL_ID")
NFA_CHANNEL_ID = _env_int("NFA_CHANNEL_ID")
SUPORTE_CHANNEL_ID = _env_int("SUPORTE_CHANNEL_ID")
NITRO_CHANNEL_ID = _env_int("NITRO_CHANNEL_ID")
CAPCUT_CHANNEL_ID = _env_int("CAPCUT_CHANNEL_ID")
SPOTIFY_CHANNEL_ID = _env_int("SPOTIFY_CHANNEL_ID")
PEDIDO_RESTOCK_CHANNEL_ID = _env_int("PEDIDO_RESTOCK_CHANNEL_ID")
AVISO_RESTOCK_CHANNEL_ID = _env_int("AVISO_RESTOCK_CHANNEL_ID")

CARGO_MEMBRO = _CFG["cargos"]["membro"]
CARGO_EQUIPE = _CFG["cargos"].get("equipe", "equipe")
CARGO_BOTS = _CFG["cargos"].get("bots", "bots")
CARGO_CLIENTE = _CFG["cargos"]["cliente"]
CARGOS_NIVEIS = _CFG[
    "cargos_niveis"
]  # o valor 0 é o cargo de cliente e nunca é removido

EDITAVEIS = _CFG["editaveis"]  # padrões das chaves que o banco pode sobrepor

MP_TIMEOUT_S = _CFG["mercado_pago_timeout_s"]

EFEMERA_S = _CFG[
    "efemera_s"
]  # o Discord só permite apagar mensagens de interação em até 900s
ENTREGA_DM_FECHA_S = _CFG["entrega_fecha_dm_s"]
RESERVA_MAX_MINUTOS = _CFG["reserva_max_minutos"]
RESTOCK_PEDIDOS_DIA = _CFG["restock_pedidos_por_dia"]

CORES = {nome: int(hexa.lstrip("#"), 16) for nome, hexa in _CFG["cores"].items()}

NUKE_JANELA_S = _CFG["antinuke"]["janela_s"]
NUKE_CREATE_LIMITE = _CFG["antinuke"]["limite_criacao"]
NUKE_DELETE_LIMITE = _CFG["antinuke"]["limite_exclusao"]
NUKE_BLOQUEIO_S = _CFG["antinuke"].get(
    "bloqueio_s", 30
)  # sem criar canal por esse tempo, o bloqueio termina

# Anti-raid: por autor, (máximo permitido, janela em segundos)
RAID_LIMITES = {tipo: tuple(par) for tipo, par in _CFG["raid"]["limites"].items()}
RAID_MENCOES_MAX = _CFG["raid"]["mencoes_max"]
RAID_AUDIT_JANELA_S = _CFG["raid"]["audit_janela_s"]
RAID_COOLDOWN_S = _CFG["raid"]["cooldown_s"]
RAID_REINCIDENCIA_S = _CFG["raid"]["reincidencia_s"]

SPAM_MAX_MSGS = _CFG["spam"]["max_msgs"]
SPAM_JANELA_S = _CFG["spam"]["janela_s"]
SPAM_TIMEOUT_S = _CFG["spam"]["timeout_s"]
MAX_THREAD_MSGS = _CFG["spam"]["max_msgs_thread"]
