"""Ghost Agent: /agente (iniciar, encerrar, diario, desfazer), >agente e o canal fixo. Só o dono.

Sessão = tarefa por canal (ghost/agente/loop.py). Mensagens do dono no canal vão para a tarefa. Ações de risco
médio e alto pausam com botão de aprovação; a tarefa continua com o resultado.
"""

import logging
import time

import discord
from discord import app_commands
from discord.ext import commands

from ...config import settings
from ...agente import conversa, diario, ferramentas, loop, prompts, provedor
from ...data import store
from ...services import notify
from ...ui.emojis import E
from ..router import route

log = logging.getLogger("agente")

PARADO = False  # >agente parar liga; >agente ligar desliga
CHAVE_CANAL = "agente_canal"  # canal fixo definido por comando (guardado no banco)


def _dono(user_id: int) -> bool:
    return user_id == settings.ADMIN_ID


def _falam_com_o_agente(bot, message) -> bool:
    """Só responde quando o dono fala com ele: menciona o bot, responde a uma mensagem dele, começa com
    'ghost' ou 'agente', ou está numa conversa (ele falou no canal há pouco)."""
    if bot.user is not None and any(m.id == bot.user.id for m in message.mentions):
        return True
    ref = message.reference
    autor_ref = getattr(getattr(ref, "resolved", None), "author", None) if ref else None
    if bot.user is not None and autor_ref is not None and autor_ref.id == bot.user.id:
        return True
    if message.content.strip().lower().startswith(("ghost", "agente")):
        return True
    return time.monotonic() - loop.ULTIMO_AGENTE.get(message.channel.id, -1e9) < loop.JANELA_CONVERSA_S


def _canal_fixo() -> int:
    """Canal fixo do agente: o definido por comando; se não houver, o AGENT_CHANNEL_ID do .env (0 = nenhum)."""
    valor = store.get_config(CHAVE_CANAL) or ""
    if valor.isdigit():
        return int(valor)
    return settings.AGENT_CANAL_ID


def _texto_canal() -> str:
    canal = _canal_fixo()
    if not canal:
        return (f"{E.information} Nenhum canal fixo do Ghost Agent. Use `/agente canal` "
                "escolhendo o canal, ou `/agente iniciar` em qualquer canal.")
    origem = "definido por comando" if (store.get_config(CHAVE_CANAL) or "").isdigit() else "do .env"
    return f"{E.information} Canal fixo do Ghost Agent: <#{canal}> ({origem})."


def _resolver_canal(guild, valor: str):
    """Canal deste servidor a partir do valor da lista (ID), de uma menção <#id> ou de um ID digitado.
    Aceita canal de texto, de voz e thread (o agente envia mensagem em todos eles)."""
    if guild is None:
        return None
    ident = (valor or "").strip().strip("<#>")
    if not ident.isdigit():
        return None
    canal = guild.get_channel_or_thread(int(ident))
    if isinstance(canal, (discord.TextChannel, discord.VoiceChannel, discord.Thread)):
        return canal
    return None


async def _mudar_canal(canal_id: int | None, autor) -> str:
    """canal_id None tira o canal guardado no banco; sem ele, vale o do .env (se houver)."""
    store.set_config(CHAVE_CANAL, str(canal_id) if canal_id else "")
    if canal_id:
        texto = f"{E.correct} Canal fixo do Ghost Agent definido: <#{canal_id}>."
    else:
        texto = f"{E.correct} Canal fixo removido. Vale o do .env, se houver."
    await notify.registrar(
        "agente_canal_alterado",
        f"{E.information} Canal fixo do Ghost Agent alterado",
        settings.CORES["info"],
        [("Canal", str(canal_id) if canal_id else "removido"), ("Por", f"{autor} ({autor.id})")],
    )
    return texto


def _linhas_diario() -> str:
    return (
        "\n".join(diario.rotulo(e) for e in diario.ultimas(15))
        or f"{E.information} O diário está vazio."
    )


def _montar_desfazer(numero: int, autor_id: int) -> tuple[str, str | None]:
    """Monta o plano de reversão. Nada é desfeito aqui: só vira plano para o dono aprovar."""
    erro = diario.conferir_desfazer({"id": numero})
    if erro:
        return f"{E.wrong} {erro[0].upper() + erro[1:]}.", None
    acao = {
        "ferramenta": "desfazer_acao",
        "args": {"id": numero},
        "resumo": ferramentas.FERRAMENTAS["desfazer_acao"].resumo({"id": numero}),
        "perigo": "medio",
    }
    ident = loop.plano_direto([acao], autor_id)
    return (
        f"Plano para desfazer. Aprove se for isso:\n{loop.linhas_do_plano(loop.PLANOS[ident])}",
        ident,
    )


def _iniciar(canal, dono) -> str:
    loop.abrir(canal, dono)
    conversa.definir_ligada(canal.id, True)  # fica ligado mesmo se o bot reiniciar
    return f"{E.correct} Ghost Agent ligado neste canal. Fala normal; `/agente encerrar` para parar."


def _encerrar(canal_id: int) -> str:
    estava_ligada = conversa.ligada(canal_id)
    tinha_sessao = loop.fechar(canal_id)
    conversa.definir_ligada(canal_id, False)
    if not (estava_ligada or tinha_sessao):
        return f"{E.information} Não tem sessão do Ghost Agent neste canal."
    return f"{E.correct} Sessão encerrada. O histórico fica guardado; `/agente novo` começa do zero."


async def _receber(canal, texto: str, dono) -> None:
    if PARADO:
        await canal.send(f"{E.alert} O Ghost Agent está parado. Use `>agente ligar`.")
        return
    modelo = provedor.do_ambiente()
    if modelo is None:
        await canal.send(
            f"{E.wrong} Modelo do Ghost Agent não configurado: confira AGENT_PROVIDER e AGENT_API_KEY no .env.",
            delete_after=10,
        )
        return
    await loop.receber(canal.id, texto, modelo, store.get_config("agente_estilo"), dono)


class Agente(commands.Cog):
    grupo_agente = app_commands.Group(name="agente", description="[ dono ]")

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @grupo_agente.command(
        name="iniciar", description="[ dono ]"
    )
    async def agente_iniciar(self, interaction: discord.Interaction) -> None:
        if not _dono(interaction.user.id):
            await interaction.response.send_message(
                f"{E.wrong} Só o dono usa o Ghost Agent.", ephemeral=True
            )
            return
        if interaction.guild is None:
            await interaction.response.send_message(
                "Use o agente em um canal do servidor.", ephemeral=True
            )
            return
        await interaction.response.send_message(
            _iniciar(interaction.channel, interaction.user), ephemeral=True
        )

    @grupo_agente.command(
        name="encerrar", description="[ dono ]"
    )
    async def agente_encerrar(self, interaction: discord.Interaction) -> None:
        if not _dono(interaction.user.id):
            await interaction.response.send_message(
                f"{E.wrong} Só o dono usa o Ghost Agent.", ephemeral=True
            )
            return
        await interaction.response.send_message(
            _encerrar(interaction.channel_id), ephemeral=True
        )

    @grupo_agente.command(name="canal", description="[ dono ] Mostra ou define o canal fixo do Ghost Agent")
    @app_commands.describe(canal="Digite o nome do canal e escolha na lista",
                           remover="Tira o canal guardado por comando (volta ao .env, se houver)")
    async def agente_canal(
        self,
        interaction: discord.Interaction,
        canal: str | None = None,
        remover: bool = False,
    ) -> None:
        if not _dono(interaction.user.id):
            await interaction.response.send_message(
                f"{E.wrong} Só o dono usa o Ghost Agent.", ephemeral=True
            )
            return
        if remover:
            texto = await _mudar_canal(None, interaction.user)
        elif canal is not None:
            destino = _resolver_canal(interaction.guild, canal)
            if destino is None:
                texto = (f"{E.wrong} Canal não encontrado neste servidor. Escolha um canal de texto, "
                         "de voz ou uma thread da lista.")
            else:
                texto = await _mudar_canal(destino.id, interaction.user)
        else:
            texto = _texto_canal()
        await interaction.response.send_message(texto, ephemeral=True)

    @agente_canal.autocomplete("canal")
    async def agente_canal_autocomplete(self, interaction: discord.Interaction, atual: str):
        if not _dono(interaction.user.id) or interaction.guild is None:
            return []
        termo = atual.lower().lstrip("#")
        canais = sorted(
            (c for c in interaction.guild.channels
             if isinstance(c, (discord.TextChannel, discord.VoiceChannel)) and termo in c.name.lower()),
            key=lambda c: c.position,
        )
        return [app_commands.Choice(name=f"#{c.name}"[:100], value=str(c.id)) for c in canais[:25]]

    @grupo_agente.command(name="permissao", description="[ dono ] Define se uma ferramenta roda direto, pergunta ou é negada")
    @app_commands.describe(ferramenta="Nome da ferramenta (ex.: apagar_canal)", acao="permitir, perguntar ou negar")
    @app_commands.choices(acao=[app_commands.Choice(name=p, value=p) for p in ferramentas.POLITICAS])
    async def agente_permissao(
        self, interaction: discord.Interaction, ferramenta: str, acao: app_commands.Choice[str]
    ) -> None:
        if not _dono(interaction.user.id):
            await interaction.response.send_message(f"{E.wrong} Só o dono usa o Ghost Agent.", ephemeral=True)
            return
        try:
            ferramentas.definir_politica(ferramenta, acao.value)
        except ValueError:
            await interaction.response.send_message(
                f"{E.wrong} Ferramenta desconhecida. Veja os nomes com `/agente permissoes`.", ephemeral=True)
            return
        await notify.registrar(
            "agente_politica_alterada",
            f"{E.information} Permissão do Ghost Agent alterada",
            settings.CORES["info"],
            [("Ferramenta", ferramenta), ("Nova política", acao.value),
             ("Por", f"{interaction.user} ({interaction.user.id})")],
        )
        await interaction.response.send_message(f"{E.correct} `{ferramenta}`: {acao.value}.", ephemeral=True)

    @agente_permissao.autocomplete("ferramenta")
    async def agente_permissao_autocomplete(self, interaction: discord.Interaction, atual: str):
        termo = atual.lower()
        return [app_commands.Choice(name=n, value=n) for n in ferramentas.FERRAMENTAS if termo in n][:25]

    @grupo_agente.command(name="permissoes", description="[ dono ] Mostra a política de cada ferramenta")
    async def agente_permissoes(self, interaction: discord.Interaction) -> None:
        if not _dono(interaction.user.id):
            await interaction.response.send_message(f"{E.wrong} Só o dono usa o Ghost Agent.", ephemeral=True)
            return
        linhas = [f"`{nome}`: {politica}" for nome, politica in ferramentas.politicas_atuais().items()]
        await interaction.response.send_message("\n".join(linhas)[:1900], ephemeral=True)

    @grupo_agente.command(name="novo", description="[ dono ] Apaga o histórico deste canal (segue ligado)")
    async def agente_novo(self, interaction: discord.Interaction) -> None:
        if not _dono(interaction.user.id):
            await interaction.response.send_message(f"{E.wrong} Só o dono usa o Ghost Agent.", ephemeral=True)
            return
        loop.zerar(interaction.channel_id)
        await interaction.response.send_message(f"{E.correct} Histórico apagado. Começamos do zero.", ephemeral=True)

    @grupo_agente.command(name="contexto", description="[ dono ] Arquivo com regras que o agente segue sempre")
    @app_commands.describe(arquivo="Arquivo .txt ou .md com as regras (até 20 mil caracteres)",
                           remover="Apaga o contexto guardado")
    async def agente_contexto(self, interaction: discord.Interaction,
                              arquivo: discord.Attachment | None = None, remover: bool = False) -> None:
        if not _dono(interaction.user.id):
            await interaction.response.send_message(f"{E.wrong} Só o dono usa o Ghost Agent.", ephemeral=True)
            return
        if remover:
            store.set_config(loop.CHAVE_CONTEXTO, "")
            await interaction.response.send_message(f"{E.correct} Contexto removido.", ephemeral=True)
            return
        if arquivo is None:
            atual = store.get_config(loop.CHAVE_CONTEXTO) or ""
            await interaction.response.send_message(
                f"{E.information} Contexto atual: {len(atual)} caracteres. Mande um arquivo para trocar, "
                "ou `remover:True` para apagar.", ephemeral=True)
            return
        if arquivo.size > 20_000:
            await interaction.response.send_message(f"{E.wrong} Arquivo grande demais (máximo 60 KB).", ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        try:
            texto = (await arquivo.read()).decode("utf-8").strip()[: prompts.MAX_CONTEXTO]
        except UnicodeDecodeError:
            await interaction.followup.send(f"{E.wrong} O arquivo precisa estar em texto (UTF-8).", ephemeral=True)
            return
        store.set_config(loop.CHAVE_CONTEXTO, texto)
        await notify.registrar(
            "agente_contexto_alterado",
            f"{E.information} Contexto do Ghost Agent alterado",
            settings.CORES["info"],
            [("Tamanho", f"{len(texto)} caracteres"), ("Por", f"{interaction.user} ({interaction.user.id})")],
        )
        await interaction.followup.send(
            f"{E.correct} Contexto salvo ({len(texto)} caracteres). Ele entra em toda conversa, "
            "então quanto menor, mais barato.", ephemeral=True)

    @grupo_agente.command(
        name="diario", description="[ dono ]"
    )
    async def agente_diario(self, interaction: discord.Interaction) -> None:
        if not _dono(interaction.user.id):
            await interaction.response.send_message(
                f"{E.wrong} Só o dono vê o diário do Ghost Agent.", ephemeral=True
            )
            return
        await interaction.response.send_message(_linhas_diario()[:1900], ephemeral=True)

    @grupo_agente.command(
        name="desfazer",
        description="[ dono ]",
    )
    @app_commands.describe(numero="Número da ação no diário (veja com /agente diario)")
    async def agente_desfazer(
        self, interaction: discord.Interaction, numero: int
    ) -> None:
        if not _dono(interaction.user.id):
            await interaction.response.send_message(
                f"{E.wrong} Só o dono desfaz ações do Ghost Agent.", ephemeral=True
            )
            return
        texto, ident = _montar_desfazer(numero, interaction.user.id)
        await interaction.response.send_message(
            texto[:1900],
            ephemeral=True,
            view=loop.confirmacao(ident) if ident else discord.utils.MISSING,
        )

    @commands.command(name="agente")
    async def agente_prefixo(self, ctx: commands.Context, *, pedido: str = "") -> None:
        global PARADO
        if not _dono(ctx.author.id):
            return
        if ctx.guild is None:
            await ctx.reply(
                "Use o agente em um canal do servidor.", mention_author=False
            )
            return
        comando = pedido.strip().lower()
        if comando == "iniciar":
            await ctx.reply(_iniciar(ctx.channel, ctx.author), mention_author=False)
            return
        if comando == "encerrar":
            await ctx.reply(_encerrar(ctx.channel.id), mention_author=False)
            return
        if comando == "novo":
            loop.zerar(ctx.channel.id)
            await ctx.reply(f"{E.correct} Histórico apagado. Começamos do zero.", mention_author=False)
            return
        if comando == "diario":
            await ctx.reply(_linhas_diario()[:1900], mention_author=False)
            return
        if comando.startswith("desfazer"):
            partes = comando.split()
            if len(partes) != 2 or not partes[1].isdigit():
                await ctx.reply(
                    f"{E.information} Use `>agente desfazer <número>` (veja os números com `>agente diario`).",
                    mention_author=False,
                )
                return
            texto, ident = _montar_desfazer(int(partes[1]), ctx.author.id)
            await ctx.reply(
                texto[:1900],
                view=loop.confirmacao(ident) if ident else None,
                mention_author=False,
            )
            return
        if comando.startswith("canal"):
            resto = pedido.strip()[len("canal"):].strip()
            if not resto:
                await ctx.reply(_texto_canal(), mention_author=False)
                return
            if resto.lower() == "remover":
                await ctx.reply(await _mudar_canal(None, ctx.author), mention_author=False)
                return
            canal = _resolver_canal(ctx.guild, resto)
            if canal is None:
                await ctx.reply(
                    f"{E.information} Use `>agente canal <id do canal>`, `>agente canal #canal` "
                    "ou `>agente canal remover`. O canal precisa ser deste servidor.",
                    mention_author=False,
                )
                return
            await ctx.reply(await _mudar_canal(canal.id, ctx.author), mention_author=False)
            return
        if comando.startswith("estilo"):
            novo = pedido.strip()[len("estilo") :].strip()
            if not novo:
                await ctx.reply(
                    f"{E.information} Use `>agente estilo <como ele fala>` ou `>agente estilo padrao`.",
                    mention_author=False,
                )
                return
            if novo.lower() == "padrao":
                store.set_config("agente_estilo", "")
                await ctx.reply(
                    f"{E.correct} Estilo voltou ao padrão.", mention_author=False
                )
                return
            guardado = prompts.limpar_estilo(novo)
            store.set_config("agente_estilo", guardado)
            await ctx.reply(
                f"{E.correct} Estilo salvo ({len(guardado)} caracteres).",
                mention_author=False,
            )
            return
        if comando in ("parar", "ligar"):
            PARADO = comando == "parar"
            if PARADO:
                for canal_id in tuple(loop.SESSOES):
                    loop.fechar(canal_id)
            await ctx.reply(
                f"{E.correct} Ghost Agent {'parado' if PARADO else 'ligado'}.",
                mention_author=False,
            )
            return
        await ctx.reply(
            f"{E.information} Use `>agente iniciar`, `>agente encerrar`, `>agente diario`, "
            "`>agente desfazer <n>`, `>agente estilo <texto>`, `>agente parar` ou `>agente ligar`.",
            mention_author=False,
        )

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        from ...services import incidente

        if message.guild and incidente.ativo(message.guild.id):
            return
        """No canal fixo ou numa sessão ligada, as mensagens do dono viram pedidos para o agente."""
        if message.guild is None or message.guild.id != settings.GUILD_ID:
            return
        canal_fixo_id = _canal_fixo()
        canal_fixo = bool(canal_fixo_id) and message.channel.id == canal_fixo_id
        if not (canal_fixo or loop.sessao_ativa(message.channel.id) or conversa.ligada(message.channel.id)):
            return
        if message.author.bot or not _dono(message.author.id):
            return
        pedido = message.content.strip()
        if not pedido or pedido[0] in (">", "/"):
            return
        if not _falam_com_o_agente(self.bot, message):
            return  # o dono está falando com outra pessoa ou com o servidor: o agente fica quieto
        if not loop.sessao_ativa(message.channel.id):
            loop.abrir(message.channel, message.author)
        await _receber(message.channel, pedido, message.author)

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload: discord.RawReactionActionEvent) -> None:
        """Dono reage na mensagem de aprovação do plano: 👍 (ou ✅, 🚀...) aprova, ❌ (ou 👎, 🛑) cancela."""
        if payload.user_id != settings.ADMIN_ID:
            return
        ident = loop.MENSAGENS_PLANO.get(payload.message_id)
        if ident is None:
            return
        nome = payload.emoji.name or ""
        if any(nome.startswith(r) for r in loop.REACOES_APROVAR):
            ok = True
        elif any(nome.startswith(r) for r in loop.REACOES_CANCELAR):
            ok = False
        else:
            return
        loop.decidir(ident, ok)

    @route(prefix="agente:")
    async def _confirmar(self, interaction: discord.Interaction, cid: str) -> None:
        if not _dono(interaction.user.id):
            await interaction.response.send_message(
                f"{E.wrong} Só o dono confirma ações do Ghost Agent.", ephemeral=True
            )
            return
        partes = cid.split(":")
        if len(partes) != 3 or partes[1] not in ("ok", "no"):
            await interaction.response.send_message(
                f"{E.wrong} Ação desconhecida.", ephemeral=True
            )
            return
        ident, ok = partes[2], partes[1] == "ok"

        # plano de uma tarefa: a própria tarefa aplica e segue
        if loop.decidir(ident, ok):
            await interaction.response.edit_message(
                content=f"{E.reload} Aplicando o plano..."
                if ok
                else f"{E.wrong} Plano cancelado.",
                view=None,
            )
            return

        # plano avulso (ex.: /agente desfazer)
        loop._expirar_planos()
        plano = loop.PLANOS.pop(ident, None)
        if plano is None:
            await interaction.response.edit_message(
                content=f"{E.information} Esse plano já foi resolvido.", view=None
            )
            return
        if not ok:
            await interaction.response.edit_message(
                content=f"{E.wrong} Plano cancelado.", view=None
            )
            return
        await interaction.response.edit_message(
            content=f"{E.reload} Aplicando o plano...", view=None
        )
        resultados = await loop.executar_acoes(
            interaction.guild, plano["acoes"], ident, interaction.user
        )
        await interaction.edit_original_response(
            content=f"{E.correct} Plano aplicado:\n" + "\n".join(resultados)[:1900]
        )


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Agente(bot))
