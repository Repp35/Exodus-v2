"""Log colorido no console e spinner do boot."""

import logging
import sys
import threading

from datetime import datetime

RESET = "\033[0m"
DIM = "\033[38;5;244m"
OK = "\033[38;5;114m"
WARN = "\033[38;5;221m"
ERR = "\033[38;5;203m"
INFO = "\033[38;5;141m"

_lock = threading.Lock()


def _write(glyph: str, color: str, msg: str) -> None:
    stamp = datetime.now().strftime("%H:%M:%S")
    with _lock:
        sys.stdout.write(f"{DIM}{stamp}{RESET}  {color}{glyph}{RESET} {msg}\n")
        sys.stdout.flush()


class ConsoleHandler(logging.Handler):
    _glyphs = {
        logging.DEBUG: ("·", DIM),
        logging.INFO: ("•", INFO),
        logging.WARNING: ("!", WARN),
        logging.ERROR: ("✗", ERR),
        logging.CRITICAL: ("✗", ERR),
    }

    def emit(self, record: logging.LogRecord) -> None:
        glyph, color = self._glyphs.get(record.levelno, ("•", INFO))
        _write(glyph, color, f"[{record.name}] {record.getMessage()}")
        if record.exc_info and record.levelno >= logging.ERROR:
            _write(" ", DIM, str(record.exc_info[1]))


def setup_logging(level: int = logging.INFO) -> None:
    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(ConsoleHandler())
    root.setLevel(level)
    for noisy in ("discord", "discord.http", "discord.gateway", "aiohttp"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def ok(msg: str) -> None:
    _write("✓", OK, msg)
