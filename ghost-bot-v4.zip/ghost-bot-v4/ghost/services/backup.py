"""Backup e restauração do servidor.

- Um backup por dia (o bot confere de hora em hora). Ficam os últimos MANTER arquivos em `backups/`.
- Restauração: recria o que foi apagado, ajusta o que foi alterado (nome, descrição, ícone, canais, cargos)
  e republica as vitrines. Em raid, roda sozinha depois da detecção. Também pode ser pedida no /gerenciar.
- Canais e cargos são casados pelo ID original; se não achar, procura pelo nome, para não duplicar.
- Também guarda threads (ativas e arquivadas) com os membros de cada uma, e os cargos de cada membro humano.
  As mensagens dentro das threads e os membros que saíram do servidor não são guardados.
- Mensagens: o arquivo diário em services/mensagens.py guarda o que foi escrito; a restauração reenvia nos canais recriados.
- Backups schema 2 também sincronizam emojis, cargos/canais extras e configurações gerais.
- O Discord não permite restaurar IDs, histórico completo de mensagens, membros que saíram,
  itens gerenciados por integrações ou algumas configurações exclusivas do dono.
"""

import asyncio
import base64
import io
import json
import logging
import time
from datetime import datetime, timedelta
from pathlib import Path

import discord

from .. import catalogo
from ..config import settings
from ..core.files import atomic_text
from ..data import store
from ..ui.emojis import E
from ..config.settings import CORES
from . import context, envs, notify, regras, rest

log = logging.getLogger("backup")

PASTA: Path = settings.BASE_DIR / "backups"
MANTER = 7
RAID_JANELA_S = 300
DEBOUNCE_S = 5
INTERVALO_S = 3600
_raid_ate = 0.0
_restauracao_agendada = False
_ocupado = False
# Pausa entre operações de canal: evita rajadas em PATCH /guilds/{id}/channels e PATCH /channels/{id}.
PAUSA_ENTRE_CANAIS_S = 0.6
_trava_canais = asyncio.Lock()
_SEM_VALOR = object()


# ── Arquivos ──────────────────────────────────────────────────────────────────


def arquivos() -> list[Path]:
    if not PASTA.exists():
        return []
    return sorted(PASTA.glob("backup-*.json"))


def ultimo() -> dict | None:
    arqs = arquivos()
    if not arqs:
        return None
    try:
        return json.loads(arqs[-1].read_text(encoding="utf-8"))
    except (OSError, ValueError):
        log.exception("backup %s ilegível", arqs[-1].name)
        return None


def _limpar() -> None:
    for antigo in arquivos()[:-MANTER]:
        try:
            antigo.unlink()
        except OSError:
            pass


def marcar_raid() -> None:
    global _raid_ate
    _raid_ate = time.monotonic() + RAID_JANELA_S


def em_raid() -> bool:
    from . import incidente

    return incidente.ativo() or time.monotonic() < _raid_ate


# ── Coleta ────────────────────────────────────────────────────────────────────


def _overwrites(canal) -> list[dict]:
    saida = []
    for alvo, ow in canal.overwrites.items():
        allow, deny = ow.pair()
        saida.append(
            {
                "id": str(alvo.id),
                "tipo": "cargo" if isinstance(alvo, discord.Role) else "membro",
                "allow": allow.value,
                "deny": deny.value,
            }
        )
    return saida


def _canal_dados(canal) -> dict:
    if isinstance(canal, discord.CategoryChannel):
        tipo = "categoria"
    elif isinstance(canal, discord.StageChannel):
        tipo = "palco"
    elif isinstance(canal, discord.ForumChannel):
        tipo = "forum"
    elif isinstance(canal, discord.VoiceChannel):
        tipo = "voz"
    else:
        tipo = "texto"
    dados = {
        "id": str(canal.id),
        "tipo": tipo,
        "nome": canal.name,
        "posicao": canal.position,
        "pai": str(canal.category_id) if canal.category_id else None,
        "permissoes": _overwrites(canal),
    }
    if tipo == "texto":
        dados.update(
            topico=canal.topic,
            nsfw=canal.nsfw,
            lento=canal.slowmode_delay,
            arquivo_padrao=canal.default_auto_archive_duration,
        )
    elif tipo in ("voz", "palco"):
        dados.update(
            bitrate=canal.bitrate,
            limite=canal.user_limit,
            regiao=canal.rtc_region,
            qualidade=canal.video_quality_mode.value,
        )
        if tipo == "palco":
            dados["topico"] = getattr(canal, "topic", None)
    elif tipo == "forum":
        dados.update(
            topico=canal.topic,
            nsfw=canal.nsfw,
            lento=canal.slowmode_delay,
            arquivo_padrao=canal.default_auto_archive_duration,
            lento_threads=canal.default_thread_slowmode_delay,
            layout=canal.default_layout.value,
            ordenacao=canal.default_sort_order.value,
            tags=[_tag_dados(tag) for tag in canal.available_tags],
            reacao_padrao=(
                canal.default_reaction_emoji.name
                if canal.default_reaction_emoji
                else None
            ),
        )
    return dados


async def _cargo_dados(cargo: discord.Role) -> dict:
    icone = cargo.display_icon
    return {
        "id": str(cargo.id),
        "nome": cargo.name,
        "cor": cargo.colour.value,
        "permissoes": cargo.permissions.value,
        "destaque": cargo.hoist,
        "mencionavel": cargo.mentionable,
        "posicao": cargo.position,
        "icone": await _asset_dados(icone)
        if isinstance(icone, discord.Asset)
        else None,
        "emoji": icone if isinstance(icone, str) else None,
        "cor_secundaria": cargo.secondary_colour.value
        if cargo.secondary_colour
        else None,
        "cor_terciaria": cargo.tertiary_colour.value if cargo.tertiary_colour else None,
    }


async def _baixar(url: str) -> bytes:
    """Baixa pela URL. Emoji e figurinha expõem a URL como texto (não são Asset), então não têm .read()."""
    http = await rest._http()
    async with http.get(url) as resp:
        if resp.status >= 400:
            raise RuntimeError(f"HTTP {resp.status} ao baixar {url}")
        return await resp.read()


async def _asset_dados(asset) -> str | None:
    if asset is None:
        return None
    return base64.b64encode(await asset.read()).decode("ascii")


def _tag_dados(tag: discord.ForumTag) -> dict:
    emoji = tag.emoji
    return {
        "id": str(tag.id),
        "nome": tag.name,
        "emoji_id": str(emoji.id)
        if isinstance(emoji, discord.PartialEmoji) and emoji.id
        else None,
        "emoji_nome": emoji.name
        if isinstance(emoji, discord.PartialEmoji) and emoji.id
        else None,
        "emoji": str(emoji)
        if emoji and not (isinstance(emoji, discord.PartialEmoji) and emoji.id)
        else None,
        "moderada": tag.moderated,
    }


def _emoji_de_backup(item: dict, mapa: dict):
    if item.get("emoji_id"):
        old = item["emoji_id"]
        return discord.PartialEmoji(
            name=item.get("emoji_nome") or "emoji",
            id=int(mapa.get(f"emoji:{old}", old)),
        )
    return item.get("emoji")


def _tag_de_backup(item: dict, mapa: dict) -> discord.ForumTag:
    return discord.ForumTag(
        name=item["nome"],
        emoji=_emoji_de_backup(item, mapa),
        moderated=item.get("moderada", False),
    )


async def _webhooks_dados(guild: discord.Guild) -> list[dict]:
    saida = []
    for canal in _canais_do_servidor(guild):
        if not hasattr(canal, "webhooks"):
            continue
        for webhook in await canal.webhooks():
            if webhook.type != discord.WebhookType.incoming:
                continue  # webhooks de integrações/aplicações são geridos pelo próprio Discord
            saida.append(
                {
                    "id": str(webhook.id),
                    "canal": str(canal.id),
                    "nome": webhook.name,
                    "criador": str(webhook.user.id) if webhook.user else None,
                    "icone": await _asset_dados(webhook.avatar),
                }
            )
    return saida


async def _convites_dados(guild: discord.Guild) -> list[dict]:
    convites = await guild.invites()
    return [
        {
            "codigo": convite.code,
            "canal": str(convite.channel.id) if convite.channel else None,
            "criador": str(convite.inviter.id) if convite.inviter else None,
            "criado_em": convite.created_at.isoformat() if convite.created_at else None,
            "expira_em": convite.expires_at.isoformat() if convite.expires_at else None,
            "max_age": convite.max_age,
            "max_uses": convite.max_uses,
            "usos": convite.uses,
            "temporario": convite.temporary,
            "target_type": convite.target_type.value if convite.target_type else None,
            "target_user": str(convite.target_user.id) if convite.target_user else None,
            "target_application": convite.target_application.id
            if convite.target_application
            else None,
        }
        for convite in convites
        if convite.channel is not None
    ]


async def _banimentos_dados(guild: discord.Guild) -> list[dict]:
    return [
        {"user_id": str(entry.user.id), "motivo": entry.reason}
        async for entry in guild.bans(limit=None)
    ]


async def _figurinhas_dados(guild: discord.Guild) -> list[dict]:
    saida = []
    for sticker in await guild.fetch_stickers():
        if sticker.guild_id != guild.id or not sticker.available:
            continue
        saida.append(
            {
                "id": str(sticker.id),
                "nome": sticker.name,
                "descricao": sticker.description,
                "emoji": sticker.emoji,
                "formato": sticker.format.value,
                "imagem": base64.b64encode(await _baixar(sticker.url)).decode("ascii"),
            }
        )
    return saida


async def _automod_dados(guild: discord.Guild) -> list[dict]:
    saida = []
    for rule in await guild.fetch_automod_rules():
        trigger = rule.trigger
        saida.append(
            {
                "id": str(rule.id),
                "nome": rule.name,
                "evento": rule.event_type.value,
                "gatilho": {
                    "tipo": trigger.type.value,
                    "keywords": trigger.keyword_filter,
                    "presets": trigger.presets.value if trigger.presets else 0,
                    "allow_list": trigger.allow_list,
                    "mention_limit": trigger.mention_limit,
                    "regex": trigger.regex_patterns,
                    "mention_raid_protection": trigger.mention_raid_protection,
                },
                "acoes": [
                    {
                        "tipo": action.type.value,
                        "canal": action.channel_id,
                        "duracao": action.duration.total_seconds()
                        if action.duration
                        else None,
                        "mensagem": action.custom_message,
                    }
                    for action in rule.actions
                ],
                "habilitada": rule.enabled,
                "cargos_isentos": [str(x) for x in rule.exempt_role_ids],
                "canais_isentos": [str(x) for x in rule.exempt_channel_ids],
            }
        )
    return saida


async def _eventos_programados_dados(guild: discord.Guild) -> list[dict]:
    saida = []
    for event in await guild.fetch_scheduled_events(with_counts=False):
        saida.append(
            {
                "id": str(event.id),
                "nome": event.name,
                "descricao": event.description,
                "inicio": event.start_time.isoformat(),
                "fim": event.end_time.isoformat() if event.end_time else None,
                "privacidade": event.privacy_level.value,
                "tipo": event.entity_type.value,
                "canal": str(event.channel_id) if event.channel_id else None,
                "local": event.location,
                "estado": event.status.value,
                "imagem": await _asset_dados(event.cover_image),
            }
        )
    return saida


async def _emojis_dados(guild: discord.Guild) -> list[dict]:
    saida = []
    for emoji in guild.emojis:
        try:
            imagem = await _baixar(emoji.url)
        except Exception as exc:  # rede ou HTTP: nunca gravar snapshot incompleto
            # Nunca grave um snapshot incompleto que depois possa apagar emojis válidos.
            raise RuntimeError(
                f"não foi possível incluir o emoji {emoji.name} no backup"
            ) from exc
        saida.append(
            {
                "id": str(emoji.id),
                "nome": emoji.name,
                "imagem": base64.b64encode(imagem).decode("ascii"),
                "animado": emoji.animated,
                "cargos": [str(role.id) for role in emoji.roles],
            }
        )
    return saida


def _canais_do_servidor(guild: discord.Guild) -> list:
    return [
        c
        for c in guild.channels
        if isinstance(
            c,
            (
                discord.TextChannel,
                discord.VoiceChannel,
                discord.StageChannel,
                discord.ForumChannel,
                discord.CategoryChannel,
            ),
        )
    ]


def _cargos_do_servidor(guild: discord.Guild) -> list[discord.Role]:
    return [r for r in guild.roles if not r.managed and r != guild.default_role]


async def _icone(guild: discord.Guild) -> tuple[str | None, str | None]:
    if guild.icon is None:
        return None, None
    try:
        dados = await guild.icon.read()
    except discord.HTTPException:
        return None, None
    return base64.b64encode(dados).decode(), guild.icon.key


def _thread_dados(thread: discord.Thread, arquivada: bool, membros: list[str]) -> dict:
    return {
        "id": str(thread.id),
        "nome": thread.name,
        "pai": str(thread.parent_id),
        "privado": thread.type == discord.ChannelType.private_thread,
        "arquivada": arquivada,
        "duracao": thread.auto_archive_duration,
        "membros": membros,
        "travada": thread.locked,
        "slowmode": thread.slowmode_delay,
        "convidavel": thread.invitable,
        "tags": [str(tag.id) for tag in getattr(thread, "applied_tags", [])],
    }


async def _membros_da_thread(thread: discord.Thread) -> list[str]:
    try:
        return [str(m.id) for m in await thread.fetch_members()]
    except discord.HTTPException as exc:
        raise RuntimeError(
            f"membros da thread {thread.id} não puderam ser listados"
        ) from exc


async def _threads_dados(guild: discord.Guild) -> list[dict]:
    """Threads ativas e arquivadas (públicas e privadas que o bot consegue ver), com quem está em cada uma.
    As mensagens dentro das threads não são guardadas."""
    saida, vistos = [], set()
    for thread in guild.threads:
        vistos.add(thread.id)
        saida.append(_thread_dados(thread, False, await _membros_da_thread(thread)))
    for canal in guild.channels:
        if not hasattr(canal, "archived_threads"):
            continue
        tipos = (False,) if isinstance(canal, discord.ForumChannel) else (False, True)
        for privado in tipos:
            try:
                async for thread in canal.archived_threads(
                    limit=None,
                    **(
                        {}
                        if isinstance(canal, discord.ForumChannel)
                        else {"private": privado}
                    ),
                ):
                    if thread.id in vistos:
                        continue
                    vistos.add(thread.id)
                    saida.append(
                        _thread_dados(thread, True, await _membros_da_thread(thread))
                    )
            except discord.HTTPException as exc:
                raise RuntimeError(
                    f"não foi possível listar threads arquivadas de {canal.name}; backup cancelado"
                ) from exc
    return saida


async def _membros_cargos_dados(guild: discord.Guild) -> dict:
    """Cargos de membros (menos @everyone e cargos gerenciados por integração)."""
    try:
        if not guild.chunked:
            await guild.chunk()
    except (discord.HTTPException, discord.ClientException) as exc:
        raise RuntimeError(
            "não foi possível listar todos os membros; backup cancelado"
        ) from exc
    return {
        str(m.id): [
            str(r.id) for r in m.roles if r != guild.default_role and not r.managed
        ]
        for m in guild.members
    }


async def _membros_perfil_dados(guild: discord.Guild) -> dict:
    """Metadados de perfil do membro que são do servidor; avatares globais não são copiados."""
    saida = {}
    for member in guild.members:
        saida[str(member.id)] = {
            "apelido": member.nick,
            "avatar_servidor": await _asset_dados(member.guild_avatar),
            "timeout_ate": member.timed_out_until.isoformat()
            if member.timed_out_until
            else None,
        }
    return saida


def listar() -> list[tuple[Path, dict]]:
    """Todos os backups, do mais novo para o mais antigo, já lidos."""
    saida = []
    for arq in reversed(arquivos()):
        try:
            saida.append((arq, json.loads(arq.read_text(encoding="utf-8"))))
        except (OSError, ValueError):
            log.warning("backup %s ilegível: ignorado", arq.name)
    return saida


def caminho_do(nome_arquivo: str) -> Path | None:
    """Só aceita um arquivo que esteja de fato na pasta de backups (evita caminhos inventados)."""
    for arq in arquivos():
        if arq.name == nome_arquivo:
            return arq
    return None


_IGNORADOS = {"criado_em", "motivo", "nome"}


def _sem_mudanca(antigo: dict, novo: dict) -> bool:
    """Compara o conteúdo do backup, sem data, motivo e nome."""

    def limpo(d):
        return {k: v for k, v in d.items() if k not in _IGNORADOS}

    return json.dumps(limpo(antigo), sort_keys=True) == json.dumps(
        limpo(novo), sort_keys=True
    )


def apagar(nome_arquivo: str) -> bool:
    """Apaga um backup da pasta. Só apaga arquivo que de fato existe na pasta de backups."""
    arq = caminho_do(nome_arquivo)
    from . import incidente

    if arq is None or (
        incidente.ativo()
        and incidente.estado(settings.GUILD_ID).get("backup") == nome_arquivo
    ):
        return False
    try:
        arq.unlink()
    except OSError:
        log.exception("backup %s não apagado", nome_arquivo)
        return False
    return True


async def criar(
    guild: discord.Guild, motivo: str = "manual", nome: str | None = None
) -> Path | None:
    """Grava um backup agora. Não grava durante raid: o estado daquela hora não serve.
    Quem chama decide se registra no log (o diário não registra; o comando /backup registra)."""
    if em_raid():
        log.info("backup diário adiado: raid em andamento")
        return None
    icone, icone_chave = await _icone(guild)
    dados = {
        "schema_version": 4,
        "guild_id": str(guild.id),
        "criado_em": datetime.now().isoformat(timespec="seconds"),
        "motivo": motivo,
        "nome": (nome or "").strip()[:60],
        "servidor": {
            "nome": guild.name,
            "descricao": guild.description,
            "icone": icone,
            "icone_chave": icone_chave,
            "everyone": guild.default_role.permissions.value,
            "banner": await _asset_dados(guild.banner),
            "banner_chave": guild.banner.key if guild.banner else None,
            "splash": await _asset_dados(guild.splash),
            "splash_chave": guild.splash.key if guild.splash else None,
            "discovery_splash": await _asset_dados(guild.discovery_splash),
            "discovery_splash_chave": guild.discovery_splash.key
            if guild.discovery_splash
            else None,
            "widget_enabled": guild.widget_enabled,
            "widget_channel": str(guild.widget_channel.id)
            if guild.widget_channel
            else None,
            "discoverable": "DISCOVERABLE" in guild.features,
            "premium_progress": guild.premium_progress_bar_enabled,
            "safety_alerts_channel": str(guild.safety_alerts_channel.id)
            if guild.safety_alerts_channel
            else None,
            "raid_alerts_disabled": getattr(guild, "raid_alerts_disabled", None),
            "invites_disabled": guild.invites_paused(),
            "mfa_level": guild.mfa_level.value,
            "afk_timeout": guild.afk_timeout,
            "afk_channel": str(guild.afk_channel.id) if guild.afk_channel else None,
            "default_notifications": guild.default_notifications.value,
            "verification_level": guild.verification_level.value,
            "explicit_content_filter": guild.explicit_content_filter.value,
            "system_channel": str(guild.system_channel.id)
            if guild.system_channel
            else None,
            "system_channel_flags": guild.system_channel_flags.value,
            "preferred_locale": str(guild.preferred_locale),
            "rules_channel": str(guild.rules_channel.id)
            if guild.rules_channel
            else None,
            "public_updates_channel": str(guild.public_updates_channel.id)
            if guild.public_updates_channel
            else None,
        },
        "cargos": [await _cargo_dados(r) for r in _cargos_do_servidor(guild)],
        "canais": [_canal_dados(c) for c in _canais_do_servidor(guild)],
        "emojis": await _emojis_dados(guild),
        "threads": await _threads_dados(guild),
        "membros_cargos": await _membros_cargos_dados(guild),
        "webhooks": await _webhooks_dados(guild),
        "convites": await _convites_dados(guild),
        "banimentos": await _banimentos_dados(guild),
        "figurinhas": await _figurinhas_dados(guild),
        "automod": await _automod_dados(guild),
        "eventos_programados": await _eventos_programados_dados(guild),
        "membros": await _membros_perfil_dados(guild),
    }
    # Só pede a tela se o servidor tem a feature: sem ela a API responde "não existe" (NotFound).
    if "COMMUNITY" in guild.features and "WELCOME_SCREEN_ENABLED" in guild.features:
        try:
            welcome = await guild.welcome_screen()
            dados["servidor"]["welcome_screen"] = {
                "enabled": welcome.enabled,
                "description": welcome.description,
                "channels": [
                    {
                        "canal": str(x.channel.id),
                        "descricao": x.description,
                        "emoji_id": str(x.emoji.id) if x.emoji and x.emoji.id else None,
                        "emoji_nome": x.emoji.name if x.emoji else None,
                        "emoji_unicode": str(x.emoji)
                        if x.emoji and not x.emoji.id
                        else None,
                    }
                    for x in welcome.welcome_channels
                ],
            }
        except discord.HTTPException as exc:
            # Opcional e sem risco no restore: sem tela de boas-vindas no backup, o restore só não mexe nela.
            log.warning("tela de boas-vindas não salva no backup (%s): %s", exc.status, exc.text)
            dados["servidor"].pop("welcome_screen", None)
    from . import mensagens

    dados["mensagens"] = await mensagens.snapshot(guild)
    if not dados["mensagens"]["completo"]:
        canais_com_falha = ", ".join(dados["mensagens"]["falhas"][:10])
        raise RuntimeError(
            f"histórico incompleto em {canais_com_falha}; backup cancelado"
        )
    if motivo == "diário":
        anterior = ultimo()
        if anterior is not None and _sem_mudanca(anterior, dados):
            log.info("backup diário: nada mudou desde o último, nada gravado")
            return None
    if em_raid():
        raise RuntimeError(
            "Raid detectada durante a coleta; snapshot descartado para preservar o backup anterior"
        )
    PASTA.mkdir(parents=True, exist_ok=True)
    caminho = PASTA / f"backup-{datetime.now():%Y-%m-%d-%H%M%S-%f}.json"
    atomic_text(caminho, json.dumps(dados, ensure_ascii=False))
    _limpar()
    log.info(
        "backup criado: %s (%d canais, %d cargos, %d threads, %d membros com cargos)",
        caminho.name,
        len(dados["canais"]),
        len(dados["cargos"]),
        len(dados["threads"]),
        len(dados["membros_cargos"]),
    )
    return caminho


# ── Restauração ───────────────────────────────────────────────────────────────


def _permissoes(guild: discord.Guild, mapa: dict, lista: list[dict]) -> dict:
    saida = {}
    for ow in lista:
        novo = mapa.get(ow["id"], ow["id"])
        if ow["tipo"] == "cargo":
            alvo = guild.get_role(int(novo))
        else:
            alvo = guild.get_member(int(novo))
        if alvo is None:
            if ow["tipo"] == "cargo" and ow["deny"]:
                raise ValueError("cargo com permissão de negação não restaurado")
            continue
        saida[alvo] = discord.PermissionOverwrite.from_pair(
            discord.Permissions(ow["allow"]), discord.Permissions(ow["deny"])
        )
    return saida


async def _servidor(guild: discord.Guild, dados: dict) -> list[str]:
    s = dados["servidor"]
    payload: dict = {}
    if guild.name != s["nome"]:
        payload["name"] = s["nome"]
    if (guild.description or "") != (s["descricao"] or ""):
        payload["description"] = s["descricao"] or ""
    for nome, campo, chave in (
        ("icon", "icone", "icone_chave"),
        ("banner", "banner", "banner_chave"),
        ("splash", "splash", "splash_chave"),
        ("discovery_splash", "discovery_splash", "discovery_splash_chave"),
    ):
        atual = getattr(guild, nome, None)
        if (atual.key if atual else None) != s.get(chave):
            bruto = s.get(campo)
            payload[nome] = base64.b64decode(bruto) if bruto else None
    feitos = []
    if payload:
        try:
            await guild.edit(reason="Restaurar backup", **payload)
            feitos.append("nome/descrição/ícone/banner")
        except (discord.HTTPException, TypeError, ValueError) as exc:
            log.warning("não consegui ajustar o servidor: %s", exc)
            feitos.append("falha ao restaurar nome/descrição/ícone/banner")
    return feitos


async def _config_servidor(guild: discord.Guild, s: dict, mapa: dict) -> list[str]:
    """Restaura configurações de servidor depois que canais e IDs já foram reconciliados."""
    if "afk_timeout" not in s:  # backup legado: não inventa valores ausentes
        return []

    def canal(chave):
        valor = s.get(chave)
        if not valor:
            return None
        novo = mapa.get(str(valor), str(valor))
        return guild.get_channel(int(novo))

    kwargs = {
        "afk_timeout": s["afk_timeout"],
        "afk_channel": canal("afk_channel"),
        "default_notifications": discord.NotificationLevel(s["default_notifications"]),
        "verification_level": discord.VerificationLevel(s["verification_level"]),
        "explicit_content_filter": discord.ContentFilter(s["explicit_content_filter"]),
        "system_channel": canal("system_channel"),
        "system_channel_flags": discord.SystemChannelFlags._from_value(
            s["system_channel_flags"]
        ),
        "preferred_locale": discord.Locale(s["preferred_locale"]),
        "rules_channel": canal("rules_channel"),
        "public_updates_channel": canal("public_updates_channel"),
    }
    for key, param in (
        ("widget_enabled", "widget_enabled"),
        ("premium_progress", "premium_progress_bar_enabled"),
        ("discoverable", "discoverable"),
    ):
        if key in s:
            kwargs[param] = s[key]
    if s.get("raid_alerts_disabled") is not None:
        kwargs["raid_alerts_disabled"] = s["raid_alerts_disabled"]
    if "mfa_level" in s:
        kwargs["mfa_level"] = discord.MFALevel(s["mfa_level"])
    feitos = []
    try:
        await guild.edit(**kwargs, reason="Restauração do backup")
        feitos.append("configurações gerais do servidor")
    except (discord.HTTPException, TypeError, ValueError, AttributeError) as exc:
        log.warning("não consegui restaurar todas as configurações gerais: %s", exc)
        feitos.append("algumas configurações gerais falharam")
    # Canais de widget e de alertas de segurança: só entram se o backup tinha um canal de verdade.
    # Um null não vira None no edit, e cada um vai numa chamada própria para não derrubar o resto.
    for chave in ("widget_channel", "safety_alerts_channel"):
        if not s.get(chave):
            continue
        alvo = canal(chave)
        if alvo is None:
            log.warning("%s do backup não existe mais no servidor; ignorado", chave)
            feitos.append(f"{chave} ignorado: canal não existe mais")
            continue
        try:
            await guild.edit(**{chave: alvo}, reason="Restauração do backup")
        except (discord.HTTPException, TypeError, ValueError, AttributeError) as exc:
            log.warning("%s não restaurado: %s", chave, exc)
            feitos.append(f"falha ao restaurar {chave}")
    # Restore the community welcome screen after mapping its channel and emoji references.
    if "welcome_screen" in s and "WELCOME_SCREEN_ENABLED" in guild.features:
        try:
            current = await guild.welcome_screen()
            channels = []
            for item in s["welcome_screen"].get("channels", []):
                cid = mapa.get(item["canal"], item["canal"])
                channel_obj = guild.get_channel(int(cid))
                if channel_obj is None:
                    raise ValueError(f"canal {cid} da tela de boas-vindas não existe")
                emoji = item.get("emoji_unicode")
                if item.get("emoji_id"):
                    old = item["emoji_id"]
                    emoji = discord.PartialEmoji(
                        name=item.get("emoji_nome") or "emoji",
                        id=int(mapa.get(f"emoji:{old}", old)),
                    )
                channels.append(
                    discord.WelcomeChannel(
                        channel=channel_obj, description=item["descricao"], emoji=emoji
                    )
                )
            await current.edit(
                description=s["welcome_screen"].get("description") or "",
                welcome_channels=channels,
                enabled=s["welcome_screen"].get("enabled", False),
                reason="Restaurar backup",
            )
        except (discord.HTTPException, ValueError, TypeError) as exc:
            log.warning("tela de boas-vindas não restaurada: %s", exc)
            feitos.append("falha ao restaurar tela de boas-vindas")
    if guild.default_role.permissions.value != s.get("everyone"):
        try:
            await guild.default_role.edit(
                permissions=discord.Permissions(s["everyone"]), reason="Backup"
            )
            feitos.append("permissões do @everyone")
        except discord.HTTPException as exc:
            log.warning("não consegui ajustar @everyone: %s", exc)
            feitos.append("permissões do @everyone falharam")
    return feitos


async def _cargos(guild: discord.Guild, dados: dict, mapa: dict) -> list[str]:
    feitos = []
    existentes = {r.id: r for r in guild.roles}
    used = set()
    for c in dados["cargos"]:
        alvo = existentes.get(int(c["id"]))
        try:
            if alvo is None:
                candidates = [
                    r
                    for r in guild.roles
                    if r.name == c["nome"] and not r.managed and r.id not in used
                ]
                alvo = candidates[0] if len(candidates) == 1 else None
            if alvo is None:
                alvo = await guild.create_role(
                    name=c["nome"],
                    permissions=discord.Permissions(c["permissoes"]),
                    colour=discord.Colour(c["cor"]),
                    hoist=c["destaque"],
                    display_icon=base64.b64decode(c["icone"])
                    if c.get("icone")
                    else c.get("emoji"),
                    secondary_colour=c.get("cor_secundaria"),
                    tertiary_colour=c.get("cor_terciaria"),
                    mentionable=c["mencionavel"],
                    reason="Backup",
                )
                feitos.append(f"cargo {c['nome']} recriado")
            elif (
                alvo.permissions.value,
                alvo.name,
                alvo.colour.value,
                alvo.hoist,
                alvo.mentionable,
                alvo.secondary_colour.value if alvo.secondary_colour else None,
                alvo.tertiary_colour.value if alvo.tertiary_colour else None,
                await _asset_dados(alvo.display_icon)
                if isinstance(alvo.display_icon, discord.Asset)
                else alvo.display_icon,
            ) != (
                c["permissoes"],
                c["nome"],
                c["cor"],
                c["destaque"],
                c["mencionavel"],
                c.get("cor_secundaria"),
                c.get("cor_terciaria"),
                c.get("icone") or c.get("emoji"),
            ):
                await alvo.edit(
                    name=c["nome"],
                    permissions=discord.Permissions(c["permissoes"]),
                    colour=discord.Colour(c["cor"]),
                    hoist=c["destaque"],
                    mentionable=c["mencionavel"],
                    display_icon=base64.b64decode(c["icone"])
                    if c.get("icone")
                    else c.get("emoji"),
                    secondary_colour=c.get("cor_secundaria"),
                    tertiary_colour=c.get("cor_terciaria"),
                    reason="Backup",
                )
                feitos.append(f"cargo {c['nome']} ajustado")
            used.add(alvo.id)
            mapa[c["id"]] = str(alvo.id)
        except discord.HTTPException as exc:
            log.warning("cargo %s não restaurado: %s", c["nome"], exc)
    if dados.get("schema_version", 1) >= 2 and all(
        c["id"] in mapa for c in dados["cargos"]
    ):
        desejados = set(mapa.values())
        for cargo in list(guild.roles):
            if (
                cargo == guild.default_role
                or cargo.managed
                or str(cargo.id) in desejados
            ):
                continue
            try:
                await cargo.delete(reason="Não existia no backup restaurado")
                feitos.append(f"cargo extra {cargo.name} removido")
            except discord.HTTPException as exc:
                log.warning("cargo extra %s não removido: %s", cargo.name, exc)
                feitos.append(f"falha ao remover cargo extra {cargo.name}")
        posicoes = {
            guild.get_role(int(mapa[c["id"]])): int(c.get("posicao", i + 1))
            for i, c in enumerate(dados["cargos"])
            if c["id"] in mapa and guild.get_role(int(mapa[c["id"]]))
        }
        if posicoes:
            try:
                await guild.edit_role_positions(
                    positions=posicoes, reason="Ordem de cargos do backup"
                )
                feitos.append("ordem dos cargos restaurada")
            except discord.HTTPException as exc:
                log.warning("ordem dos cargos não restaurada: %s", exc)
                feitos.append("falha ao restaurar ordem dos cargos")
    return feitos


def _difere(canal, chave: str, novo) -> bool:
    """Compara o valor atual do canal com o do backup. Sem diferença, não há PATCH."""
    if chave == "overwrites":
        return True  # a comparação já foi feita antes de chegar aqui
    if chave == "position":
        return canal.position != novo
    if chave == "available_tags":
        return [t.name for t in canal.available_tags] != [t.name for t in novo]
    atual = getattr(canal, chave, _SEM_VALOR)
    if atual is _SEM_VALOR:
        return True
    if chave == "default_reaction_emoji":
        return str(atual) != str(novo)
    return atual != novo


async def _canais(guild: discord.Guild, dados: dict, mapa: dict) -> list[str]:
    """Uma restauração de canais por vez: restaurações concorrentes geram rajadas de PATCH de posição."""
    async with _trava_canais:
        return await _canais_em_fila(guild, dados, mapa)


async def _canais_em_fila(guild: discord.Guild, dados: dict, mapa: dict) -> list[str]:
    feitos = []
    used = set()
    # Ordem original (posição salva). Sem posição no backup, usa a posição atual do servidor.
    ordenados = regras.ordem_canais(dados["canais"], _posicoes_atuais(guild, dados, mapa))
    for c in ordenados:
        atuais = {str(ch.id): ch for ch in _canais_do_servidor(guild)}
        atual = atuais.get(mapa.get(c["id"], c["id"]))
        if atual is None:
            candidates = [
                ch
                for ch in atuais.values()
                if ch.name == c["nome"]
                and _tipo_bate(ch, c["tipo"])
                and ch.id not in used
            ]
            atual = candidates[0] if len(candidates) == 1 else None
        pai_id = mapa.get(c["pai"], c["pai"]) if c["pai"] else None
        pai = guild.get_channel(int(pai_id)) if pai_id else None
        try:
            overwrites = _permissoes(guild, mapa, c["permissoes"])
            if atual is not None:
                used.add(atual.id)
                mapa[c["id"]] = str(atual.id)
                if c["tipo"] == "forum":
                    atuais_tags = {tag.name: tag for tag in atual.available_tags}
                    for tag in c.get("tags", []):
                        if tag["nome"] in atuais_tags:
                            mapa[f"forum_tag:{tag['id']}"] = str(
                                atuais_tags[tag["nome"]].id
                            )
                if atual.name != c["nome"] or (
                    c["tipo"] != "categoria"
                    and getattr(atual, "category_id", None) != getattr(pai, "id", None)
                ):
                    await atual.edit(
                        name=c["nome"],
                        **({} if c["tipo"] == "categoria" else {"category": pai}),
                        reason="Backup",
                    )
                    feitos.append(f"canal {c['nome']} ajustado")
                    await asyncio.sleep(PAUSA_ENTRE_CANAIS_S)
                if c["tipo"] in ("texto", "forum") and getattr(
                    atual, "topic", None
                ) != c.get("topico"):
                    await atual.edit(topic=c["topico"], reason="Backup")
                    feitos.append(f"tópico de {c['nome']} ajustado")
                    await asyncio.sleep(PAUSA_ENTRE_CANAIS_S)
                attrs = {"position": c["posicao"]}
                if c["tipo"] == "texto":
                    attrs.update(
                        nsfw=c.get("nsfw", False),
                        slowmode_delay=c.get("lento", 0),
                        default_auto_archive_duration=c.get("arquivo_padrao", 1440),
                    )
                elif c["tipo"] in ("voz", "palco"):
                    attrs.update(
                        bitrate=min(c.get("bitrate", 64000), guild.bitrate_limit),
                        user_limit=c.get("limite", 0),
                        rtc_region=c.get("regiao"),
                        video_quality_mode=discord.VideoQualityMode(
                            c.get("qualidade", 1)
                        ),
                    )
                elif c["tipo"] == "forum":
                    tags = [_tag_de_backup(x, mapa) for x in c.get("tags", [])]
                    attrs.update(
                        nsfw=c.get("nsfw", False),
                        slowmode_delay=c.get("lento", 0),
                        default_auto_archive_duration=c.get("arquivo_padrao", 1440),
                        default_thread_slowmode_delay=c.get("lento_threads", 0),
                        default_layout=discord.ForumLayoutType(c.get("layout", 0)),
                        default_sort_order=discord.ForumOrderType(
                            c.get("ordenacao", 0)
                        ),
                        default_reaction_emoji=_emoji_de_backup(
                            c["reacao_padrao"], mapa
                        )
                        if c.get("reacao_padrao")
                        else None,
                        available_tags=tags,
                    )
                if atual.overwrites != overwrites:
                    attrs["overwrites"] = overwrites
                # Só manda o que mudou; sem diferença nenhuma, nem chama a API.
                attrs = {k: v for k, v in attrs.items() if _difere(atual, k, v)}
                if attrs:
                    await atual.edit(**attrs, reason="Backup")
                    await asyncio.sleep(PAUSA_ENTRE_CANAIS_S)
                continue
            if c["tipo"] == "categoria":
                novo = await guild.create_category(
                    c["nome"], overwrites=overwrites, reason="Backup"
                )
            elif c["tipo"] == "voz":
                novo = await guild.create_voice_channel(
                    c["nome"],
                    overwrites=overwrites,
                    category=pai,
                    bitrate=min(c.get("bitrate") or 64000, guild.bitrate_limit),
                    user_limit=c.get("limite") or 0,
                    rtc_region=c.get("regiao"),
                    video_quality_mode=discord.VideoQualityMode(c.get("qualidade", 1)),
                    reason="Backup",
                )
            elif c["tipo"] == "palco":
                novo = await guild.create_stage_channel(
                    c["nome"],
                    overwrites=overwrites,
                    category=pai,
                    bitrate=min(c.get("bitrate") or 64000, guild.bitrate_limit),
                    user_limit=c.get("limite") or 0,
                    rtc_region=c.get("regiao"),
                    video_quality_mode=discord.VideoQualityMode(c.get("qualidade", 1)),
                    topic=c.get("topico"),
                    reason="Backup",
                )
            elif c["tipo"] == "forum":
                novo = await guild.create_forum(
                    c["nome"],
                    overwrites=overwrites,
                    category=pai,
                    topic=c.get("topico"),
                    nsfw=c.get("nsfw", False),
                    slowmode_delay=c.get("lento") or 0,
                    default_auto_archive_duration=c.get("arquivo_padrao", 1440),
                    default_thread_slowmode_delay=c.get("lento_threads", 0),
                    default_layout=discord.ForumLayoutType(c.get("layout", 0)),
                    default_sort_order=discord.ForumOrderType(c.get("ordenacao", 0)),
                    available_tags=[
                        discord.ForumTag(
                            name=x["nome"],
                            emoji=x.get("emoji"),
                            moderated=x.get("moderada", False),
                        )
                        for x in c.get("tags", [])
                    ],
                    reason="Backup",
                )
            else:
                novo = await guild.create_text_channel(
                    c["nome"],
                    overwrites=overwrites,
                    category=pai,
                    topic=c.get("topico"),
                    nsfw=c.get("nsfw", False),
                    slowmode_delay=c.get("lento") or 0,
                    default_auto_archive_duration=c.get("arquivo_padrao", 1440),
                    reason="Backup",
                )
            used.add(novo.id)
            mapa[c["id"]] = str(novo.id)
            await asyncio.sleep(PAUSA_ENTRE_CANAIS_S)
            feitos.append(f"canal {c['nome']} recriado")
            if c["tipo"] == "forum":
                atuais_tags = {tag.name: tag for tag in novo.available_tags}
                for tag in c.get("tags", []):
                    if tag["nome"] in atuais_tags:
                        mapa[f"forum_tag:{tag['id']}"] = str(
                            atuais_tags[tag["nome"]].id
                        )
        except (discord.HTTPException, ValueError) as exc:
            log.warning("canal %s não restaurado: %s", c["nome"], exc)
            feitos.append(f"falha em {c['nome']}")
    if dados.get("schema_version", 1) >= 2 and all(
        c["id"] in mapa for c in dados["canais"]
    ):
        desejados = set(mapa.values())
        extras = [
            ch for ch in _canais_do_servidor(guild) if str(ch.id) not in desejados
        ]
        # Filhos primeiro: apagar uma categoria não deve deixar canais órfãos.
        extras.sort(key=lambda ch: isinstance(ch, discord.CategoryChannel))
        for canal_extra in extras:
            try:
                await canal_extra.delete(reason="Não existia no backup restaurado")
                feitos.append(f"canal extra #{canal_extra.name} removido")
                await asyncio.sleep(PAUSA_ENTRE_CANAIS_S)
            except discord.HTTPException as exc:
                log.warning("canal extra %s não removido: %s", canal_extra.name, exc)
                feitos.append(f"falha ao remover canal extra #{canal_extra.name}")
    return feitos


async def _threads(guild: discord.Guild, dados: dict, mapa: dict) -> list[str]:
    """Recria as threads que sumiram, põe de volta os membros e arquiva as que estavam arquivadas.
    Só recria threads dentro de canais de texto que existam; forum e stage não entram no backup."""
    feitos = []
    ativas = {str(t.id): t for t in guild.threads}
    for t in dados["threads"]:
        pai_id = mapa.get(t["pai"], t["pai"])
        pai = guild.get_channel(int(pai_id)) if pai_id else None
        if not isinstance(pai, (discord.TextChannel, discord.ForumChannel)):
            log.warning("pai do tópico %s indisponível", t["nome"])
            continue
        if not t.get("membros"):
            # Sem membros ninguém consegue usar a thread: não recria. As mensagens dela também ficam de fora.
            mapa[f"sem_membros:{t['id']}"] = "1"
            feitos.append(f"tópico {t['nome']} não restaurado: sem membros")
            log.warning("tópico %s não restaurado: não tem membros", t["nome"])
            continue
        try:
            atual = ativas.get(t["id"])
            if atual is None:
                try:
                    fetched = await guild.fetch_channel(int(t["id"]))
                    if isinstance(fetched, discord.Thread):
                        atual = fetched
                except discord.NotFound:
                    pass
            if atual is None:
                candidates = [
                    x
                    for x in ativas.values()
                    if x.name == t["nome"]
                    and x.parent_id == pai.id
                    and (x.type == discord.ChannelType.private_thread) == t["privado"]
                ]
                atual = candidates[0] if len(candidates) == 1 else None
            if atual is None:
                tipo = (
                    discord.ChannelType.private_thread
                    if t["privado"]
                    else discord.ChannelType.public_thread
                )
                if isinstance(pai, discord.ForumChannel):
                    resultado = await pai.create_thread(
                        name=t["nome"],
                        content="Restaurando histórico…",
                        auto_archive_duration=t["duracao"],
                        slowmode_delay=t.get("slowmode", 0),
                        invitable=t.get("convidavel", True),
                        reason="Backup",
                    )
                    atual = resultado.thread
                else:
                    atual = await pai.create_thread(
                        name=t["nome"],
                        type=tipo,
                        auto_archive_duration=t["duracao"],
                        slowmode_delay=t.get("slowmode", 0),
                        invitable=t.get("convidavel", True),
                        reason="Backup",
                    )
                feitos.append(f"tópico {t['nome']} recriado")
            ativas[str(atual.id)] = atual
            mapa[t["id"]] = str(atual.id)
            if atual.name != t["nome"]:
                await atual.edit(name=t["nome"], reason="Backup")
            for uid in t["membros"]:
                membro = guild.get_member(int(uid))
                if membro is None or membro.bot:
                    continue
                try:
                    await atual.add_user(membro)
                except discord.HTTPException as exc:
                    log.warning("membro %s não adicionado ao tópico: %s", uid, exc)
            parent_data = next(
                (c for c in dados.get("canais", []) if c["id"] == t["pai"]), None
            )
            if parent_data and parent_data["tipo"] == "forum":
                tagmap = {tag["id"]: tag for tag in parent_data.get("tags", [])}
                tags = [
                    guild.get_channel(pai.id).get_tag(
                        int(mapa.get(f"forum_tag:{tid}", 0))
                    )
                    for tid in t.get("tags", [])
                    if tid in tagmap
                ]
                tags = [tag for tag in tags if tag is not None]
                if tags and list(atual.applied_tags) != tags:
                    await atual.edit(applied_tags=tags, reason="Backup")
            if getattr(atual, "slowmode_delay", 0) != t.get("slowmode", 0):
                await atual.edit(slowmode_delay=t.get("slowmode", 0), reason="Backup")
            if t["arquivada"] and (
                not getattr(atual, "archived", False)
                or ("travada" in t and getattr(atual, "locked", False) != t["travada"])
            ):
                await atual.edit(
                    archived=True, locked=t.get("travada", False), reason="Backup"
                )
        except discord.HTTPException as exc:
            log.warning("tópico %s não restaurado: %s", t["nome"], exc)
            feitos.append(f"falha no tópico {t['nome']}")
    if dados.get("schema_version", 1) >= 3 and all(
        t["id"] in mapa for t in dados.get("threads", [])
    ):
        desejados = {mapa[t["id"]] for t in dados.get("threads", [])}
        try:
            existentes = {str(t.id): t for t in guild.threads}
            for canal in guild.channels:
                if not hasattr(canal, "archived_threads"):
                    continue
                for privado in (
                    (False,)
                    if isinstance(canal, discord.ForumChannel)
                    else (False, True)
                ):
                    kwargs = (
                        {}
                        if isinstance(canal, discord.ForumChannel)
                        else {"private": privado}
                    )
                    async for thread in canal.archived_threads(limit=None, **kwargs):
                        existentes[str(thread.id)] = thread
            for tid, thread in existentes.items():
                if tid not in desejados:
                    await thread.delete(reason="Não existia no backup")
        except discord.HTTPException as exc:
            log.warning("limpeza de tópicos extras incompleta: %s", exc)
    return feitos


async def _membros_cargos(guild: discord.Guild, dados: dict, mapa: dict) -> list[str]:
    """Sincroniza cargos humanos ao snapshot; em schema 2 também remove cargos extras."""
    snapshot = dados.get("membros_cargos", {})
    if dados.get("schema_version", 1) >= 3:
        try:
            if not guild.chunked:
                await guild.chunk()
        except (discord.HTTPException, discord.ClientException):
            log.warning(
                "lista incompleta de membros; restauração de cargos não será destrutiva"
            )
            return ["cargos de membros não sincronizados: lista incompleta"]
        membros = list(guild.members)
    else:
        membros = [
            m
            for uid in snapshot
            if (m := guild.get_member(int(uid))) is not None and not m.bot
        ]
    alterados = 0
    from . import incidente

    for membro in membros:
        if incidente.alvo(guild.id, membro.id):
            continue
        ids = snapshot.get(str(membro.id), [])
        desejados = []
        for rid in ids:
            cargo = guild.get_role(int(mapa.get(rid, rid)))
            if cargo and not cargo.managed and cargo < guild.me.top_role:
                desejados.append(cargo)
        desejados_set = set(desejados)
        adicionar = [r for r in desejados if r not in membro.roles]
        remover = (
            [
                r
                for r in membro.roles
                if r != guild.default_role
                and not r.managed
                and r not in desejados_set
                and r < guild.me.top_role
            ]
            if dados.get("schema_version", 1) >= 3
            else []
        )
        try:
            if adicionar:
                await membro.add_roles(*adicionar, reason="Restauração do backup")
            if remover:
                await membro.remove_roles(
                    *remover, reason="Não existia no backup restaurado"
                )
            if adicionar or remover:
                alterados += 1
        except discord.HTTPException as exc:
            log.warning("cargos de %s não sincronizados: %s", membro, exc)
    perfis = dados.get("membros", {})
    for membro in membros:
        if incidente.alvo(guild.id, membro.id):
            continue
        perfil = perfis.get(str(membro.id))
        if not perfil:
            continue
        try:
            timeout = (
                datetime.fromisoformat(perfil["timeout_ate"])
                if perfil.get("timeout_ate")
                else None
            )
            if timeout and timeout <= discord.utils.utcnow():
                timeout = None
            avatar = (
                base64.b64decode(perfil["avatar_servidor"])
                if perfil.get("avatar_servidor")
                else None
            )
            avatar_atual = await _asset_dados(membro.guild_avatar)
            needs_edit = (
                membro.nick != perfil.get("apelido")
                or avatar_atual != perfil.get("avatar_servidor")
                or (membro.timed_out_until is not None and timeout is None)
                or (timeout is not None and membro.timed_out_until != timeout)
            )
            if needs_edit:
                await membro.edit(
                    nick=perfil.get("apelido"),
                    timed_out_until=timeout,
                    avatar=avatar,
                    reason="Restaurar perfil do membro",
                )
        except discord.HTTPException as exc:
            log.warning("perfil de %s não restaurado: %s", membro.id, exc)
    return [f"cargos sincronizados de {alterados} membros"] if alterados else []


async def _emojis(guild: discord.Guild, dados: dict, mapa: dict) -> list[str]:
    """Repõe emojis do backup e remove emojis criados depois do snapshot."""
    if dados.get("schema_version", 1) < 2 or "emojis" not in dados:
        return []
    feitos = []
    existentes = {e.id: e for e in guild.emojis}
    usados = set()
    for item in dados["emojis"]:
        emoji = existentes.get(int(item["id"]))
        if emoji is None:
            candidatos = [
                e for e in guild.emojis if e.name == item["nome"] and e.id not in usados
            ]
            emoji = candidatos[0] if len(candidatos) == 1 else None
        if emoji is None:
            roles = [
                guild.get_role(int(mapa.get(rid, rid)))
                for rid in item.get("cargos", [])
            ]
            roles = [r for r in roles if r is not None]
            try:
                imagem = base64.b64decode(item["imagem"], validate=True)
                emoji = await guild.create_custom_emoji(
                    name=item["nome"],
                    image=imagem,
                    roles=roles,
                    reason="Restauração do backup",
                )
                feitos.append(f"emoji :{item['nome']}: recriado")
            except (discord.HTTPException, ValueError, KeyError) as exc:
                log.warning("emoji %s não restaurado: %s", item.get("nome"), exc)
                feitos.append(f"falha no emoji :{item.get('nome', '?')}:")
                continue
        usados.add(emoji.id)
        mapa[f"emoji:{item['id']}"] = str(emoji.id)
    # Só remove extras se todas as entradas do backup foram recuperadas.
    if len(usados) == len(dados["emojis"]):
        for emoji in list(guild.emojis):
            if emoji.id in usados or emoji.managed:
                continue
            try:
                await emoji.delete(reason="Não existia no backup restaurado")
                feitos.append(f"emoji extra :{emoji.name}: removido")
            except discord.HTTPException as exc:
                log.warning("emoji extra %s não removido: %s", emoji.name, exc)
                feitos.append(f"falha ao remover emoji :{emoji.name}:")
    return feitos


async def _banimentos(guild: discord.Guild, dados: dict) -> list[str]:
    if "banimentos" not in dados:
        return []
    feitos = []
    from . import incidente

    protected = (
        {int(uid) for uid in incidente.estado(guild.id).get("alvos", {})}
        if incidente.ativo(guild.id)
        else set()
    )
    atual = {entry.user.id: entry async for entry in guild.bans(limit=None)}
    desejados = {int(x["user_id"]): x for x in dados["banimentos"]}
    for uid, entry in atual.items():
        if uid in desejados or uid in protected:
            continue
        try:
            await guild.unban(entry.user, reason="Não estava banido no backup")
            feitos.append(f"ban removido de {uid}")
        except discord.HTTPException as exc:
            log.warning("ban extra de %s não removido: %s", uid, exc)
            feitos.append(f"falha ao remover ban de {uid}")
    for uid, item in desejados.items():
        if uid in atual or uid in protected:
            continue
        try:
            await guild.ban(
                discord.Object(id=uid),
                reason=item.get("motivo") or "Ban restaurado do backup",
                delete_message_seconds=0,
            )
            feitos.append(f"ban restaurado para {uid}")
        except discord.HTTPException as exc:
            log.warning("ban de %s não restaurado: %s", uid, exc)
            feitos.append(f"falha ao restaurar ban de {uid}")
    return feitos


async def _convites(guild: discord.Guild, dados: dict, mapa: dict) -> list[str]:
    if "convites" not in dados:
        return []
    feitos = []
    from . import incidente

    s = incidente.estado(guild.id)
    revogar = {int(x) for x in s.get("revogar_convites", [])}
    atuais = await guild.invites()
    por_codigo = {x.code: x for x in atuais}
    desejados = {x["codigo"]: x for x in dados["convites"]}
    preservados = set()
    for code, item in desejados.items():
        creator = int(item["criador"]) if item.get("criador") else None
        if creator in revogar:
            feitos.append(f"convite {code} revogado pela política anti-raid")
            continue
        convite = por_codigo.get(code)
        if convite is not None:
            preservados.add(code)
            continue
        channel_id = mapa.get(str(item.get("canal")), item.get("canal"))
        channel = guild.get_channel(int(channel_id)) if channel_id else None
        if channel is None:
            feitos.append(f"falha ao restaurar convite {code}: canal ausente")
            continue
        max_age = int(item.get("max_age") or 0)
        if max_age and item.get("expira_em"):
            expires = datetime.fromisoformat(item["expira_em"])
            max_age = min(
                max_age, max(0, int((expires - discord.utils.utcnow()).total_seconds()))
            )
            if max_age == 0:
                continue
        try:
            target_type = (
                discord.InviteTarget(item["target_type"])
                if item.get("target_type")
                else None
            )
            target_user = (
                await context.bot().fetch_user(int(item["target_user"]))
                if item.get("target_user")
                else None
            )
            new = await channel.create_invite(
                max_age=max_age,
                max_uses=int(item.get("max_uses") or 0),
                temporary=bool(item.get("temporario")),
                unique=True,
                target_type=target_type,
                target_user=target_user,
                target_application_id=item.get("target_application"),
                reason="Restaurar configurações de convite do backup",
            )
            feitos.append(f"convite {code} recriado como {new.code} (uso reiniciado)")
        except discord.HTTPException as exc:
            log.warning("convite %s não restaurado: %s", code, exc)
            feitos.append(f"falha ao recriar convite {code}")
    # Durante incidente, preserve explicit revocations and delete all post-backup links.
    for invite in atuais:
        if invite.code in preservados:
            continue
        creator = getattr(invite.inviter, "id", None)
        if creator in revogar or invite.code not in desejados:
            try:
                await invite.delete(
                    reason="Convite não existia no snapshot ou foi invalidado pela raid"
                )
            except discord.HTTPException as exc:
                feitos.append(f"falha ao apagar convite extra {invite.code}")
                log.warning("convite extra %s não removido: %s", invite.code, exc)
    return feitos


async def _webhooks(guild: discord.Guild, dados: dict, mapa: dict) -> list[str]:
    if "webhooks" not in dados:
        return []
    feitos, usados = [], set()
    from ..data import store

    for item in dados["webhooks"]:
        channel_id = mapa.get(item["canal"], item["canal"])
        channel = guild.get_channel(int(channel_id))
        if channel is None or not hasattr(channel, "webhooks"):
            feitos.append(f"falha no webhook {item['nome']}: canal não existe")
            continue
        try:
            existentes = await channel.webhooks()
            webhook = discord.utils.get(existentes, id=int(item["id"]))
            if webhook is None:
                candidates = [
                    w
                    for w in existentes
                    if w.type == discord.WebhookType.incoming
                    and w.name == item["nome"]
                    and w.id not in usados
                ]
                webhook = candidates[0] if len(candidates) == 1 else None
            avatar = base64.b64decode(item["icone"]) if item.get("icone") else None
            if webhook is None:
                webhook = await channel.create_webhook(
                    name=item["nome"], avatar=avatar, reason="Restaurar backup"
                )
                feitos.append(f"webhook {item['nome']} recriado")
            elif webhook.name != item["nome"]:
                await webhook.edit(
                    name=item["nome"], avatar=avatar, reason="Restaurar backup"
                )
            usados.add(webhook.id)
            if item.get("criador"):
                store.save_webhook_creator(str(webhook.id), int(item["criador"]))
        except (discord.HTTPException, ValueError) as exc:
            log.warning("webhook %s não restaurado: %s", item["nome"], exc)
            feitos.append(f"falha ao restaurar webhook {item['nome']}")
    for channel in _canais_do_servidor(guild):
        if not hasattr(channel, "webhooks"):
            continue
        try:
            for webhook in await channel.webhooks():
                if (
                    webhook.type == discord.WebhookType.incoming
                    and webhook.id not in usados
                ):
                    await webhook.delete(reason="Webhook extra ausente no backup")
                    feitos.append(f"webhook extra {webhook.name} removido")
        except discord.HTTPException as exc:
            log.warning("limpeza de webhooks em %s falhou: %s", channel.id, exc)
            feitos.append(f"falha ao limpar webhooks do canal {channel.id}")
    return feitos


async def _figurinhas(guild: discord.Guild, dados: dict) -> list[str]:
    if "figurinhas" not in dados:
        return []
    feitos, usados = [], set()
    atuais = {s.id: s for s in await guild.fetch_stickers() if s.guild_id == guild.id}
    for item in dados["figurinhas"]:
        sticker = atuais.get(int(item["id"]))
        if sticker is None:
            candidates = [
                x
                for x in atuais.values()
                if x.name == item["nome"] and x.id not in usados
            ]
            sticker = candidates[0] if len(candidates) == 1 else None
        try:
            data = base64.b64decode(item["imagem"], validate=True)
            if sticker is not None and await _baixar(sticker.url) != data:
                await sticker.delete(reason="Arquivo da figurinha mudou desde o backup")
                sticker = None
            if sticker is None:
                ext = {1: "png", 2: "apng", 3: "json"}.get(item["formato"], "png")
                sticker = await guild.create_sticker(
                    name=item["nome"],
                    description=item.get("descricao") or "",
                    emoji=item.get("emoji") or "😀",
                    file=discord.File(io.BytesIO(data), filename=f"sticker.{ext}"),
                    reason="Restaurar backup",
                )
                feitos.append(f"figurinha {item['nome']} recriada")
            elif (sticker.name, sticker.description, sticker.emoji) != (
                item["nome"],
                item.get("descricao") or "",
                item.get("emoji") or "",
            ):
                await sticker.edit(
                    name=item["nome"],
                    description=item.get("descricao") or "",
                    emoji=item.get("emoji") or "😀",
                    reason="Restaurar backup",
                )
            usados.add(sticker.id)
        except (discord.HTTPException, ValueError, KeyError) as exc:
            log.warning("figurinha %s não restaurada: %s", item.get("nome"), exc)
            feitos.append(f"falha ao restaurar figurinha {item.get('nome', '?')}")
    if len(usados) == len(dados["figurinhas"]):
        for sticker in atuais.values():
            if sticker.id not in usados:
                try:
                    await sticker.delete(reason="Figurinha extra ausente no backup")
                    feitos.append(f"figurinha extra {sticker.name} removida")
                except discord.HTTPException as exc:
                    log.warning(
                        "figurinha extra %s não removida: %s", sticker.name, exc
                    )
                    feitos.append(f"falha ao remover figurinha extra {sticker.name}")
    return feitos


async def _automod(guild: discord.Guild, dados: dict, mapa: dict) -> list[str]:
    if "automod" not in dados:
        return []
    feitos, usados = [], set()
    existentes = await guild.fetch_automod_rules()
    for item in dados["automod"]:
        regra = discord.utils.get(existentes, id=int(item["id"]))
        if regra is None:
            candidates = [
                r for r in existentes if r.name == item["nome"] and r.id not in usados
            ]
            regra = candidates[0] if len(candidates) == 1 else None
        t = item["gatilho"]
        try:
            trigger = discord.AutoModTrigger(
                type=discord.AutoModRuleTriggerType(t["tipo"]),
                keyword_filter=t.get("keywords"),
                presets=discord.AutoModPresets._from_value(
                    [i + 1 for i in range(3) if t.get("presets", 0) & (1 << i)]
                ),
                allow_list=t.get("allow_list"),
                mention_limit=t.get("mention_limit"),
                regex_patterns=t.get("regex"),
                mention_raid_protection=t.get("mention_raid_protection"),
            )
            actions = [
                discord.AutoModRuleAction(
                    type=discord.AutoModRuleActionType(a["tipo"]),
                    channel_id=int(mapa.get(str(a["canal"]), a["canal"]))
                    if a.get("canal")
                    else None,
                    duration=timedelta(seconds=a["duracao"])
                    if a.get("duracao")
                    else None,
                    custom_message=a.get("mensagem"),
                )
                for a in item["acoes"]
            ]
            roles = [
                guild.get_role(int(mapa.get(x, x))) for x in item["cargos_isentos"]
            ]
            channels = [
                guild.get_channel(int(mapa.get(x, x))) for x in item["canais_isentos"]
            ]
            roles = [x for x in roles if x]
            channels = [x for x in channels if x]
            if regra is None:
                regra = await guild.create_automod_rule(
                    name=item["nome"],
                    event_type=discord.AutoModRuleEventType(item["evento"]),
                    trigger=trigger,
                    actions=actions,
                    enabled=item["habilitada"],
                    exempt_roles=roles,
                    exempt_channels=channels,
                    reason="Restaurar backup",
                )
                feitos.append(f"regra AutoMod {item['nome']} recriada")
            else:
                await regra.edit(
                    name=item["nome"],
                    event_type=discord.AutoModRuleEventType(item["evento"]),
                    trigger=trigger,
                    actions=actions,
                    enabled=item["habilitada"],
                    exempt_roles=roles,
                    exempt_channels=channels,
                    reason="Restaurar backup",
                )
            usados.add(regra.id)
        except (discord.HTTPException, TypeError, ValueError) as exc:
            log.warning("regra AutoMod %s não restaurada: %s", item["nome"], exc)
            feitos.append(f"falha na regra AutoMod {item['nome']}")
    if len(usados) == len(dados["automod"]):
        for rule in existentes:
            if rule.id not in usados:
                try:
                    await rule.delete(reason="Regra ausente no backup")
                except discord.HTTPException as exc:
                    log.warning("regra AutoMod extra não removida: %s", exc)
                    feitos.append(f"falha ao remover regra AutoMod {rule.name}")
    return feitos


async def _eventos_programados(
    guild: discord.Guild, dados: dict, mapa: dict
) -> list[str]:
    if "eventos_programados" not in dados:
        return []
    feitos, usados = [], set()
    atuais = await guild.fetch_scheduled_events(with_counts=False)
    for item in dados["eventos_programados"]:
        if int(item["estado"]) in (
            discord.EventStatus.completed.value,
            discord.EventStatus.canceled.value,
        ):
            continue
        event = discord.utils.get(atuais, id=int(item["id"]))
        if event is None:
            candidates = [
                e for e in atuais if e.name == item["nome"] and e.id not in usados
            ]
            event = candidates[0] if len(candidates) == 1 else None
        try:
            start = datetime.fromisoformat(item["inicio"])
            end = datetime.fromisoformat(item["fim"]) if item.get("fim") else None
            if end is not None and end <= discord.utils.utcnow():
                continue
            channel_id = (
                mapa.get(str(item["canal"]), item["canal"])
                if item.get("canal")
                else None
            )
            channel = guild.get_channel(int(channel_id)) if channel_id else None
            tipo = discord.EntityType(item["tipo"])
            kwargs = {
                "name": item["nome"],
                "description": item.get("descricao") or "",
                "start_time": start,
                "end_time": end,
                "privacy_level": discord.PrivacyLevel(item["privacidade"]),
                "entity_type": tipo,
                "image": base64.b64decode(item["imagem"])
                if item.get("imagem")
                else None,
                "reason": "Restaurar backup",
            }
            if tipo == discord.EntityType.external:
                kwargs["location"] = item.get("local")
            else:
                if channel is None:
                    raise ValueError("canal do evento ausente")
                kwargs["channel"] = channel
            if event is None:
                if start <= discord.utils.utcnow():
                    raise ValueError(
                        "evento iniciado não pode ser recriado com o mesmo estado"
                    )
                event = await guild.create_scheduled_event(**kwargs)
                feitos.append(f"evento {item['nome']} recriado")
            else:
                await event.edit(**kwargs)
            usados.add(event.id)
        except (discord.HTTPException, TypeError, ValueError) as exc:
            log.warning("evento %s não restaurado: %s", item["nome"], exc)
            feitos.append(f"falha no evento {item['nome']}")
    for event in atuais:
        if event.id not in usados:
            try:
                await event.delete(reason="Evento extra ausente no backup")
            except discord.HTTPException as exc:
                feitos.append(f"falha ao remover evento {event.name}")
                log.warning("evento extra %s não removido: %s", event.name, exc)
    return feitos


def _tipo_bate(canal, tipo: str) -> bool:
    if tipo == "categoria":
        return isinstance(canal, discord.CategoryChannel)
    if tipo == "voz":
        return isinstance(canal, discord.VoiceChannel)
    if tipo == "palco":
        return isinstance(canal, discord.StageChannel)
    if tipo == "forum":
        return isinstance(canal, discord.ForumChannel)
    return isinstance(canal, discord.TextChannel)


def _remapear_config(mapa: dict) -> list[str]:
    """Canais novos ganham o ID novo na configuração e nas mensagens de vitrine. Canais do .env não mudam sozinhos."""
    trocas = {antigo: novo for antigo, novo in mapa.items() if antigo != novo}
    if not trocas:
        return []
    avisos = []
    from ..database.connection import connection

    with connection() as conn:
        for old, new in trocas.items():
            for table in (
                "threads_ativas",
                "pedidos",
                "fechamentos_agendados",
                "restock_pedidos",
            ):
                conn.execute(
                    f"UPDATE {table} SET thread_id=? WHERE thread_id=?", (new, old)
                )
    for key, val in store.todas_configs().items():
        if key.startswith("cargo_") and key.endswith("_id") and val in trocas:
            store.set_config(key, trocas[val])
        if key in ("cargos_niveis", "cargos_niveis_compras", "cargos_niveis_mensagens"):
            levels = json.loads(val)
            for level in levels:
                if str(level.get("cargo_id")) in trocas:
                    level["cargo_id"] = trocas[str(level["cargo_id"])]
            store.set_config(key, json.dumps(levels, ensure_ascii=False))
    changed_catalogue = False
    for p in catalogo.produtos(so_ativos=False):
        doc = catalogo.doc_produto(p.id)
        if str(doc.get("canal")) in trocas:
            doc["canal"] = trocas[str(doc["canal"])]
            catalogo.gravar(doc)
            changed_catalogue = True
    if changed_catalogue:
        catalogo.recarregar()
    chaves = {k for k in settings.EDITAVEIS if k.endswith("_channel_id")}
    chaves |= {f"{v.id.lower()}_channel_id" for v in catalogo.vitrines()}
    for chave in sorted(chaves):
        valor, origem = store.config_atual(chave)
        if valor not in trocas:
            continue
        if origem == "banco":
            store.set_config(chave, trocas[valor])
            avisos.append(f"{chave} atualizado")
        elif origem == ".env":
            envs.gravar(chave.upper(), trocas[valor])
            avisos.append(f"{chave} atualizado no .env")
    # Canais fora da lista editável: canal de vendas e canal do Ghost Agent.
    for chave_env, atributo in (
        ("SALES_CHANNEL_ID", "SALES_CHANNEL_ID"),
        ("LOGS_CHANNEL_ID", "LOGS_CHANNEL_ID"),
        ("AGENT_CHANNEL_ID", "AGENT_CANAL_ID"),
    ):
        atual = str(getattr(settings, atributo, 0) or "")
        if atual and atual in trocas:
            novo = trocas[atual]
            envs.gravar(chave_env, novo)
            setattr(settings, atributo, int(novo))  # vale já, sem reiniciar
            avisos.append(f"{chave_env} atualizado no .env")
    canal_agente = store.get_config("agente_canal") or ""
    if canal_agente in trocas:
        store.set_config("agente_canal", trocas[canal_agente])
        avisos.append("canal do Ghost Agent atualizado")
    for v in catalogo.vitrines():
        salva = store.setup_message(v.id)
        if salva and str(salva["channel_id"]) in trocas:
            store.delete_setup_message(v.id)
            avisos.append(f"vitrine {v.id} será publicada de novo")
    return avisos


# ── Restauração em fases ─────────────────────────────────────────────────────
#
# Ordem: estrutura (servidor, cargos, canais na posição salva, threads com membros, cargos, convites)
# → mensagens do próprio bot (enviadas pelo bot, igual ao /setup) → vitrines (conferidas, sem duplicar)
# → pergunta ao dono no canal de logs (só se a restauração foi pedida pelo /backup)
# → mensagens de membros e outros bots (por webhook).
# O estado fica no banco. Cada envio grava checkpoint, então a retomada não repete nada.

FASES = ("estrutura", "proprias", "vitrines", "confirmacao", "membros")
_pedido_parar = False
_restore_task = None


def estado_restauracao() -> dict:
    raw = store.get_config("restauracao")
    return json.loads(raw) if raw else {"status": "nenhuma"}


def _salvar_restauracao(st: dict) -> None:
    store.set_config("restauracao", json.dumps(st, ensure_ascii=False))


def _checar_parada() -> None:
    from . import mensagens

    if _pedido_parar:
        raise mensagens.Pausado()


def _carregar_backup(nome: str) -> dict:
    caminho = PASTA / nome
    if not caminho.exists():
        raise RuntimeError("o arquivo do backup não existe mais")
    return json.loads(caminho.read_text(encoding="utf-8"))


def _posicoes_atuais(guild, dados: dict, mapa: dict) -> dict[str, int]:
    """Posição atual de cada canal do backup (por ID mapeado ou por nome). Usada só se o backup não tiver posição."""
    atuais = {str(ch.id): ch for ch in _canais_do_servidor(guild)}
    saida: dict[str, int] = {}
    for c in dados.get("canais", []):
        ch = atuais.get(mapa.get(c["id"], c["id"]))
        if ch is None:
            ch = next((x for x in atuais.values() if x.name == c["nome"]), None)
        if ch is not None:
            saida[str(c["id"])] = ch.position
    return saida


async def _estrutura(guild, dados: dict, mapa: dict) -> tuple[list[str], list[str]]:
    """Servidor, cargos, canais, threads, cargos e convites. Cada etapa é independente."""
    capturados: list[str] = []

    class CapturarFalhas(logging.Handler):
        def emit(self, record):
            if record.levelno >= logging.WARNING:
                capturados.append(record.getMessage()[:300])

    captura = CapturarFalhas()
    log.addHandler(captura)
    feitos: list[str] = []

    async def etapa(nome: str, aguardando) -> list[str]:
        try:
            return await aguardando
        except Exception as exc:
            log.error("etapa %s falhou: %s", nome, exc, exc_info=True)
            return []

    try:
        feitos += await etapa("servidor", _servidor(guild, dados))
        feitos += await etapa("cargos", _cargos(guild, dados, mapa))
        feitos += await etapa("canais", _canais(guild, dados, mapa))
        feitos += await etapa("configurações", _config_servidor(guild, dados.get("servidor", {}), mapa))
        feitos += await etapa("emojis", _emojis(guild, dados, mapa))
        feitos += await etapa("figurinhas", _figurinhas(guild, dados))
        feitos += await etapa("automod", _automod(guild, dados, mapa))
        feitos += await etapa("eventos", _eventos_programados(guild, dados, mapa))
        feitos += await etapa("tópicos e threads", _threads(guild, dados, mapa))
        feitos += await etapa("webhooks", _webhooks(guild, dados, mapa))
        feitos += await etapa("banimentos", _banimentos(guild, dados))
        feitos += await etapa("cargos dos membros", _membros_cargos(guild, dados, mapa))
        feitos += await etapa("convites", _convites(guild, dados, mapa))
    finally:
        log.removeHandler(captura)
    return feitos, capturados


async def _fases(guild, dados: dict, st: dict) -> dict:
    from . import mensagens, shelves, incidente

    mapa: dict = st.setdefault("mapa", {})
    feitos: list = st.setdefault("feitos", [])
    avisos: list = st.setdefault("avisos", [])
    bot_id = context.bot().user.id
    inicio = FASES.index(st["fase"]) if st.get("fase") in FASES else 0
    for fase in FASES[inicio:]:
        st["fase"] = fase
        _salvar_restauracao(st)
        _checar_parada()
        if fase == "estrutura":
            f, capt = await _estrutura(guild, dados, mapa)
            feitos += f
            avisos += capt
            # Canais recriados ganham o ID novo na configuração (inclusive o canal de logs).
            avisos += _remapear_config(mapa)
        elif fase == "proprias":
            r = await mensagens.restaurar_snapshot(
                guild, dados["mensagens"], mapa, fase="proprias", bot_id=bot_id, checar=_checar_parada
            )
            feitos.append(f"{r['enviadas']} mensagens do bot restauradas")
            avisos += r["falhas"]
        elif fase == "vitrines":
            if not incidente.ativo(guild.id):
                await shelves.republicar_todas()
                feitos.append("vitrines conferidas (sem duplicar)")
        elif fase == "confirmacao":
            if st.get("confirmar") and not st.get("respondido"):
                st["status"] = "aguardando"
                _salvar_restauracao(st)
                await _pedir_confirmacao(guild)
                return {"aguardando": True}
            if st.get("respondido") and not st.get("membros_autorizados"):
                feitos.append("mensagens de membros não restauradas (recusado pelo dono)")
                break
        elif fase == "membros":
            r = await mensagens.restaurar_snapshot(
                guild, dados["mensagens"], mapa, fase="membros", bot_id=bot_id, checar=_checar_parada
            )
            feitos.append(f"{r['enviadas']} mensagens de membros e bots restauradas")
            avisos += r["falhas"]
    st["status"] = "concluido"
    st["fase"] = "fim"
    _salvar_restauracao(st)
    return {"feitos": feitos, "avisos": avisos}


async def _pedir_confirmacao(guild) -> None:
    """Pergunta no canal de logs se o dono quer restaurar as mensagens de membros e de outros bots."""
    from ..ui.emojis import E
    from . import rest

    canal = int(store.ajuste("logs_channel_id") or settings.LOGS_CHANNEL_ID or 0)
    if not canal:
        log.error("sem canal de logs: não consigo pedir confirmação para restaurar mensagens")
        return
    payload = {
        "content": (
            f"<@{settings.ADMIN_ID}> {E.alert} **Restauração: mensagens de membros e de outros bots**\n"
            "A estrutura e as mensagens do próprio bot já foram restauradas.\n"
            "Deseja restaurar agora as mensagens de membros e de outros bots?"
        ),
        "components": [
            {
                "type": 1,
                "components": [
                    {"type": 2, "style": 3, "label": "Sim, restaurar", "custom_id": "rst:sim"},
                    {"type": 2, "style": 4, "label": "Não restaurar", "custom_id": "rst:nao"},
                ],
            }
        ],
    }
    await rest.send_message(canal, payload)
    log.info("confirmação pedida no canal de logs para restaurar mensagens de membros")


async def _executar(guild, dados: dict, st: dict) -> dict:
    global _ocupado, _pedido_parar
    from . import mensagens

    _ocupado = True
    try:
        resultado = await _fases(guild, dados, st)
    except mensagens.Pausado:
        st["status"] = "parado"
        _salvar_restauracao(st)
        log.warning("restauração parada pelo dono na fase %s", st.get("fase"))
        return {"pausado": True}
    except Exception as exc:
        log.exception("restauração interrompida")
        st["status"] = "erro"
        st["erro"] = str(exc)[:300]
        _salvar_restauracao(st)
        return {"erro": "Restauração interrompida; use /backup restaurar_continuar após corrigir."}
    finally:
        _ocupado = False
        _pedido_parar = False
    if resultado.get("aguardando"):
        return resultado
    await notify.registrar(
        "backup_restaurado",
        f"{E.reload} Servidor restaurado",
        CORES["info"],
        [
            ("Motivo", st.get("motivo", "manual")),
            ("Backup", st.get("arquivo", "?")),
            ("Feito", "; ".join(resultado.get("feitos", []))[:900] or "nada precisava mudar"),
            ("Avisos", "; ".join(resultado.get("avisos", []))[:900] or "nenhum"),
        ],
    )
    return resultado


def _iniciar_tarefa(guild, dados: dict, st: dict) -> None:
    global _restore_task
    _restore_task = asyncio.create_task(_executar(guild, dados, st))


async def restaurar(
    guild: discord.Guild,
    dados: dict | None = None,
    motivo: str = "manual",
    arquivo: str | None = None,
    confirmar: bool = False,
) -> dict:
    """Restauração completa. confirmar=True (pedido pelo /backup) pergunta ao dono antes das mensagens de membros."""
    global _ocupado
    dados = dados or ultimo()
    if dados is None:
        return {"erro": "Não há backup para restaurar."}
    if dados.get("guild_id") and dados["guild_id"] != str(guild.id):
        return {"erro": "Este backup pertence a outro servidor."}
    if dados.get("schema_version", 1) < 4:
        return {"erro": "Este backup antigo não inclui todas as categorias de configuração desta versão. Faça um novo backup antes de restaurar."}
    if not (dados.get("mensagens") or {}).get("completo"):
        return {"erro": "O backup de mensagens está incompleto. Nada foi alterado; faça um novo backup com acesso a todos os históricos."}
    if _ocupado or estado_restauracao().get("status") in ("rodando", "aguardando"):
        return {"erro": "Já existe uma restauração em andamento."}
    from . import incidente

    st = {
        "status": "rodando",
        "fase": "estrutura",
        "arquivo": arquivo or (arquivos()[-1].name if arquivos() else None),
        "motivo": motivo,
        "confirmar": confirmar,
        "mapa": dict(incidente.estado(guild.id).get("mapa", {})) if incidente.ativo(guild.id) else {},
        "feitos": [],
        "avisos": [],
    }
    _salvar_restauracao(st)
    if confirmar:
        _iniciar_tarefa(guild, dados, st)
        return {"iniciada": True}
    return await _executar(guild, dados, st)


async def parar() -> str:
    global _pedido_parar
    st = estado_restauracao()
    if st.get("status") == "rodando":
        _pedido_parar = True
        return "Parando no próximo ponto seguro. Use `/backup restaurar_continuar` para retomar."
    if st.get("status") == "aguardando":
        st["status"] = "parado"
        _salvar_restauracao(st)
        return "Restauração parada (estava aguardando sua confirmação)."
    return "Não há restauração em andamento."


async def continuar(guild) -> str:
    st = estado_restauracao()
    if st.get("status") != "parado":
        return "Não há restauração parada para continuar."
    if _ocupado:
        return "Já existe uma restauração em andamento."
    dados = _carregar_backup(st["arquivo"])
    st["status"] = "rodando"
    _salvar_restauracao(st)
    _iniciar_tarefa(guild, dados, st)
    return f"Continuando a restauração a partir da fase {st.get('fase')}."


async def responder_confirmacao(guild, sim: bool) -> str:
    st = estado_restauracao()
    if st.get("status") != "aguardando":
        return "Não há pedido de confirmação pendente."
    st["respondido"] = True
    st["membros_autorizados"] = bool(sim)
    st["confirmar"] = False
    st["status"] = "rodando"
    _salvar_restauracao(st)
    dados = _carregar_backup(st["arquivo"])
    _iniciar_tarefa(guild, dados, st)
    return "Restaurando mensagens de membros e bots." if sim else "Mensagens de membros não serão restauradas."


async def retomar_pendente(guild) -> None:
    """Na inicialização: retoma sozinha só o que estava rodando (queda). O que o dono parou não volta sozinho."""
    st = estado_restauracao()
    if guild is None:
        return
    if st.get("status") == "rodando" and not _ocupado:
        log.warning("retomando restauração interrompida na fase %s", st.get("fase"))
        _iniciar_tarefa(guild, _carregar_backup(st["arquivo"]), st)
    elif st.get("status") == "aguardando":
        await _pedir_confirmacao(guild)


def agendar_restauracao(guild: discord.Guild) -> None:
    """A contenção coordena silêncio, punições e restauração; não usa timer cego."""
    from . import incidente

    asyncio.create_task(incidente.iniciar(guild, "Alterações em massa"))


# ── Diário ────────────────────────────────────────────────────────────────────


def _precisa_backup() -> bool:
    arqs = arquivos()
    if not arqs:
        return True
    return time.time() - arqs[-1].stat().st_mtime > 24 * 3600


async def _loop() -> None:
    while True:
        try:
            guild = (
                context.bot().get_guild(settings.GUILD_ID)
                if settings.GUILD_ID
                else None
            )
            if guild is not None and _precisa_backup():
                await criar(guild, motivo="diário")
            if guild is not None and not em_raid():
                from . import mensagens

                await mensagens.atualizar_avatares(guild)
                await mensagens.arquivar(guild)
            if guild is not None:
                from . import raid

                await raid.renovar_timeouts(guild)
            from . import config_backup

            config_backup.diario()
        except Exception:
            log.exception("falha no backup diário")
        await asyncio.sleep(INTERVALO_S)


_loop_task = None
_restore_task = None


def iniciar() -> None:
    global _loop_task
    if _loop_task is None or _loop_task.done():
        _loop_task = asyncio.create_task(_loop())


async def close():
    for task in (_loop_task, _restore_task):
        if task is not None:
            task.cancel()
    await asyncio.gather(
        *(t for t in (_loop_task, _restore_task) if t is not None),
        return_exceptions=True,
    )
