"""Arquiva mensagens para restauração e gera snapshots completos por backup.

No snapshot, inclui mensagens de membros, bots e webhooks em canais e threads legíveis.
Na restauração, substitui as mensagens atuais e reapresenta o nome/foto e a hora original
com webhooks, mantendo conteúdos, embeds e componentes quando a API aceita o payload.
O arquivo incremental em JSONL permanece para compatibilidade com backups antigos.
"""

import asyncio
import json
import logging
from pathlib import Path

import discord

from ..data import store
from ..config import settings
from ..core.files import atomic_text
from . import context, regras, rest

log = logging.getLogger("mensagens")

PASTA: Path = settings.BASE_DIR / "backups" / "mensagens"
AVATARES: Path = settings.BASE_DIR / "backups" / "avatares"
CURSORES = PASTA / "_cursores.json"
INDICE_AVATARES = AVATARES / "_indice.json"
NOME_WEBHOOK = "Ghost backup"
FLAG_COMPONENTES_V2 = 1 << 15
ANEXOS: Path = settings.BASE_DIR / "backups" / "anexos"  # arquivos baixados no momento do backup


# ── Fotos ─────────────────────────────────────────────────────────────────────


def _ler_json(caminho: Path, padrao):
    try:
        return json.loads(caminho.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return padrao


async def atualizar_avatares(guild: discord.Guild) -> int:
    """Guarda a foto atual de cada membro humano (uma vez por dia). Reaproveita a foto se não mudou."""
    AVATARES.mkdir(parents=True, exist_ok=True)
    indice = _ler_json(INDICE_AVATARES, {})
    http = await rest._http()
    baixadas = 0
    try:
        if not guild.chunked:
            await guild.chunk()
    except (discord.HTTPException, discord.ClientException):
        log.warning("lista de membros indisponível: fotos podem faltar")
    for membro in guild.members:
        if membro.bot:
            continue
        uid = str(membro.id)
        atual = indice.get(uid)
        url = str(membro.display_avatar.url)
        chave = membro.display_avatar.key
        if (
            atual
            and atual.get("chave") == chave
            and (AVATARES / atual["arquivo"]).exists()
        ):
            atual["url"] = url
            continue
        try:
            async with http.get(url) as resp:
                if resp.status != 200:
                    continue
                dados = await resp.read()
        except Exception:
            log.warning("foto de %s não baixada", uid)
            continue
        extensao = "gif" if str(chave).startswith("a_") else "png"
        arquivo = f"{uid}_{chave}.{extensao}"
        (AVATARES / arquivo).write_bytes(dados)
        indice[uid] = {"chave": chave, "arquivo": arquivo, "url": url}
        baixadas += 1
    atomic_text(INDICE_AVATARES, json.dumps(indice, ensure_ascii=False))
    return baixadas


# ── Arquivo ───────────────────────────────────────────────────────────────────


def _canais_do_arquivo(guild: discord.Guild) -> list[int]:
    ids = [c.id for c in guild.text_channels]
    ids += [t.id for t in guild.threads]
    return ids


async def _buscar(canal_id: int, cursor: str | None) -> list[dict]:
    """Todas as mensagens novas do canal, sem limite de quantidade."""
    saida: list[dict] = []
    if cursor is None:
        antes = None
        while True:
            qs = "?limit=100" + (f"&before={antes}" if antes else "")
            lote = await rest.request("GET", f"/channels/{canal_id}/messages{qs}") or []
            if not lote:
                break
            saida.extend(lote)
            antes = min(int(m["id"]) for m in lote)
            if len(lote) < 100:
                break
    else:
        depois = cursor
        while True:
            lote = (
                await rest.request(
                    "GET", f"/channels/{canal_id}/messages?limit=100&after={depois}"
                )
                or []
            )
            if not lote:
                break
            saida.extend(lote)
            depois = str(max(int(m["id"]) for m in lote))
            if len(lote) < 100:
                break
    return saida


def _registro(m: dict, canal_id: int, indice: dict) -> dict:
    autor = m.get("author") or {}
    uid = autor.get("id")
    membro = m.get("member") or {}
    foto = indice.get(str(uid)) or {}
    return {
        "id": m["id"],
        "canal": str(canal_id),
        "data": m.get("timestamp"),
        "autor": {
            "id": uid,
            "usuario": autor.get("username"),
            "nome_publico": autor.get("global_name"),
            "apelido": membro.get("nick"),
            "foto_arquivo": foto.get("arquivo"),
            "foto_url": foto.get("url")
            or (
                f"https://cdn.discordapp.com/avatars/{uid}/{autor['avatar']}.png"
                if autor.get("avatar")
                else None
            ),
        },
        "conteudo": m.get("content") or "",
        "embeds": m.get("embeds") or [],
        "componentes": m.get("components") or [],
        "flags": m.get("flags") or 0,
        "anexos": [
            {
                "id": str(a.get("id")),
                "nome": a.get("filename"),
                "url": a.get("url"),
                "tipo": a.get("content_type"),
                "tamanho": a.get("size") or 0,
                "arquivo": None,
            }
            for a in m.get("attachments") or []
        ],
    }


async def snapshot(guild: discord.Guild) -> dict:
    """Captura o histórico acessível inteiro; incompleto significa que a restauração falha fechado."""
    ids = {c.id for c in guild.text_channels}
    ids.update(t.id for t in guild.threads)
    falhas: list[str] = []
    for canal in guild.channels:
        if not hasattr(canal, "archived_threads"):
            continue
        tipos = (False,) if isinstance(canal, discord.ForumChannel) else (False, True)
        for privado in tipos:
            try:
                async for thread in canal.archived_threads(
                    limit=None,
                    **(
                        {}
                        if isinstance(canal, discord.ForumChannel)
                        else {"private": privado}
                    ),
                ):
                    ids.add(thread.id)
            except (discord.HTTPException, TypeError) as exc:
                falhas.append(f"threads:{canal.id}")
                log.warning(
                    "threads arquivadas de %s não capturadas: %s", canal.id, exc
                )
    indice = _ler_json(INDICE_AVATARES, {})
    canais: dict[str, list[dict]] = {}
    for canal_id in sorted(ids):
        try:
            lote = await _buscar(canal_id, None)
        except (rest.DiscordHTTPError, rest.DiscordTransportError) as exc:
            falhas.append(str(canal_id))
            log.warning("histórico do canal %s não foi capturado: %s", canal_id, exc)
            continue
        lote.sort(key=lambda m: int(m["id"]))
        # O snapshot inclui mensagens de membros, bots, webhooks e do próprio Ghost.
        registros = [_registro(m, canal_id, indice) for m in lote]
        for r in registros:
            for a in r["anexos"]:
                a["arquivo"] = await _guardar_anexo(a)
        canais[str(canal_id)] = registros
    return {"completo": not falhas, "canais": canais, "falhas": falhas}


async def _guardar_anexo(a: dict) -> str | None:
    """Baixa o anexo agora, enquanto o link ainda vale. Sem isso, a mensagem apagada perde o arquivo."""
    if not a.get("url") or not a.get("id"):
        return None
    ANEXOS.mkdir(parents=True, exist_ok=True)
    nome_seguro = "".join(c for c in (a.get("nome") or "arquivo") if c.isalnum() or c in "._-")[:80]
    destino = ANEXOS / f"{a['id']}__{nome_seguro or 'arquivo'}"
    if destino.exists():
        return str(destino)
    dados = await rest.baixar_bytes(a["url"], regras.LIMITE_ARQUIVO_PADRAO)
    if dados is None:
        log.warning("anexo %s (%s) não pôde ser guardado no backup", a["id"], a.get("nome"))
        return None
    destino.write_bytes(dados)
    return str(destino)


async def arquivar(guild: discord.Guild) -> int:
    """Acrescenta ao arquivo as mensagens novas de cada canal. Ignora as do próprio bot. Devolve quantas gravou."""
    PASTA.mkdir(parents=True, exist_ok=True)
    cursores = _ler_json(CURSORES, {})
    indice = _ler_json(INDICE_AVATARES, {})
    proprio = context.bot().user.id
    gravadas = 0
    for canal_id in _canais_do_arquivo(guild):
        chave = str(canal_id)
        try:
            lote = await _buscar(canal_id, cursores.get(chave))
        except (rest.DiscordHTTPError, rest.DiscordTransportError) as exc:
            log.warning("canal %s não lido: %s", canal_id, exc)
            continue
        if not lote:
            continue
        lote.sort(key=lambda m: int(m["id"]))
        cursores[chave] = str(lote[-1]["id"])
        linhas = [
            _registro(m, canal_id, indice)
            for m in lote
            if (m.get("author") or {}).get("id") != str(proprio)
        ]
        if linhas:
            with (PASTA / f"{chave}.jsonl").open("a", encoding="utf-8") as arq:
                for r in linhas:
                    arq.write(json.dumps(r, ensure_ascii=False) + "\n")
            gravadas += len(linhas)
    atomic_text(CURSORES, json.dumps(cursores))
    log.info("arquivo de mensagens: %d mensagens gravadas", gravadas)
    return gravadas


# ── Restauração ───────────────────────────────────────────────────────────────


class Pausado(Exception):
    """O dono pediu para parar. O checkpoint já está gravado; continuar retoma a partir dele."""


_CAMPOS_EMBED = ("title", "type", "description", "url", "color", "fields", "timestamp", "footer", "author")
_WEBHOOKS: dict[int, tuple[str, str]] = {}


def _ler_canal(canal_id: str) -> list[dict]:
    caminho = PASTA / f"{canal_id}.jsonl"
    if not caminho.exists():
        return []
    saida = []
    for linha in caminho.read_text(encoding="utf-8").splitlines():
        try:
            saida.append(json.loads(linha))
        except ValueError:
            continue
    return saida


def _embeds_limpos(embeds: list[dict]) -> list[dict]:
    """Reenvia o embed como estava. Miniatura e imagem voltam só com a URL (não o objeto da API)."""
    saida = []
    for e in embeds or []:
        limpo = {k: e[k] for k in _CAMPOS_EMBED if k in e}
        for chave in ("image", "thumbnail", "video"):
            if isinstance(e.get(chave), dict) and e[chave].get("url"):
                limpo[chave] = {"url": e[chave]["url"]}
        saida.append(limpo)
    return saida[:10]


def _conteudo(r: dict, limite: int, agora: float) -> tuple[str, list[tuple[str, bytes, str]], list[str]]:
    """Texto da mensagem, arquivos a subir e avisos. Nunca descarta a mensagem por causa de anexo.

    Imagem, GIF e vídeo vão como link (preview). Outros arquivos sobem como arquivo, usando o que foi
    guardado no backup. Se nada disso existir, o link ainda válido é usado; senão fica um aviso.
    """
    from pathlib import Path as _P

    textos: list[str] = []
    arquivos: list[tuple[str, bytes, str]] = []
    avisos: list[str] = []
    for a in r.get("anexos") or []:
        nome = a.get("nome") or "arquivo"
        url = a.get("url")
        tipo = a.get("tipo") or "application/octet-stream"
        local = a.get("arquivo")
        cabe = (a.get("tamanho") or 0) <= limite and len(arquivos) < regras.MAX_ARQUIVOS_POR_MENSAGEM
        tem_arquivo = bool(local) and _P(local).exists() and cabe
        if regras.e_midia(a.get("tipo"), nome):
            if regras.url_valida(url, agora):
                textos.append(url)
            elif tem_arquivo:
                arquivos.append((nome, _P(local).read_bytes(), tipo))
            else:
                avisos.append(f"[mídia indisponível: {nome}]")
            continue
        if tem_arquivo:
            arquivos.append((nome, _P(local).read_bytes(), tipo))
        elif regras.url_valida(url, agora):
            textos.append(url)
        else:
            avisos.append(f"[anexo indisponível: {nome}]")
    texto = regras.limpar_links(r.get("conteudo") or "")
    partes = [p for p in [texto, *textos, *avisos] if p]
    return "\n".join(partes), arquivos, avisos


def _payload(r: dict, *, webhook: bool, limite: int, agora: float) -> tuple[dict, list, bool, list[str]]:
    """Monta o envio de uma mensagem arquivada. Devolve (payload, arquivos, usa Components V2, avisos)."""
    texto, arquivos, avisos = _conteudo(r, limite, agora)
    payload: dict = {"allowed_mentions": {"parse": []}}
    if webhook:
        autor = r["autor"]
        base = autor.get("apelido") or autor.get("nome_publico") or autor.get("usuario")
        payload["username"] = regras.nome_mensagem(base, regras.hora_de_belem(r.get("data")))
        payload["avatar_url"] = autor.get("foto_url") or None
    if r.get("componentes"):
        comps = list(r["componentes"])
        if texto:
            comps.append({"type": 10, "content": texto[:2000]})
        payload["components"] = comps or [{"type": 10, "content": "-"}]
        payload["flags"] = FLAG_COMPONENTES_V2
        return payload, arquivos, True, avisos
    payload["content"] = (texto or "-")[:2000]
    payload["embeds"] = _embeds_limpos(r.get("embeds") or [])
    return payload, arquivos, False, avisos


async def _webhook(canal: discord.TextChannel, recriar: bool = False) -> tuple[str, str]:
    if not recriar and canal.id in _WEBHOOKS:
        return _WEBHOOKS[canal.id]
    achado = None
    if not recriar:
        for wh in await canal.webhooks():
            if (
                wh.name == NOME_WEBHOOK
                and wh.token
                and wh.user
                and wh.user.id == context.bot().user.id
            ):
                achado = wh
                break
    if achado is None:
        achado = await canal.create_webhook(name=NOME_WEBHOOK, reason="Restaurar mensagens")
    from . import incidente

    incidente._replay.add(achado.id)
    _WEBHOOKS[canal.id] = (str(achado.id), achado.token)
    return _WEBHOOKS[canal.id]


async def _enviar_webhook(pai, destino, payload, arquivos, v2: bool) -> dict:
    """Envia pelo webhook. Se o webhook sumiu (404), recria e tenta uma vez. Nunca repete após timeout."""
    thread = f"thread_id={destino.id}" if isinstance(destino, discord.Thread) else ""
    for tentativa in range(2):
        wid, token = await _webhook(pai, recriar=tentativa > 0)
        partes = [thread, "wait=true"] + (["with_components=true"] if v2 else [])
        caminho = f"/webhooks/{wid}/{token}?" + "&".join(p for p in partes if p)
        corpo = payload
        if arquivos:
            corpo = {**payload, "attachments": [{"id": i, "filename": n} for i, (n, _, _) in enumerate(arquivos)]}
        try:
            return await rest.request("POST", caminho, corpo, arquivos=arquivos or None)
        except rest.DiscordHTTPError as exc:
            if exc.status == 404 and tentativa == 0:
                _WEBHOOKS.pop(pai.id, None)
                continue
            raise
    raise RuntimeError("webhook indisponível")


async def _enviar_proprio(destino, payload, arquivos) -> dict:
    corpo = payload
    if arquivos:
        corpo = {**payload, "attachments": [{"id": i, "filename": n} for i, (n, _, _) in enumerate(arquivos)]}
    return await rest.request("POST", f"/channels/{destino.id}/messages", corpo, arquivos=arquivos or None)


def _igual_original(original: dict, r: dict) -> bool:
    return (
        original.get("content", "") == r.get("conteudo", "")
        and [a.get("id") for a in original.get("attachments", [])] == [a.get("id") for a in r.get("anexos", [])]
    )


async def _sincronizar(destino, registros: list[dict], atuais: list[dict], enviar, checar) -> tuple[int, list[str]]:
    """Garante que cada mensagem do backup existe no canal, sem repetir nenhuma.

    Para cada mensagem do backup: se ela (ou o envio dela, gravado em replay:{canal}:{id}) já está no canal,
    mantém. Se não, envia de novo e grava o ID do envio. Mensagens do mesmo tipo que não estão no backup
    são apagadas. Assim, uma retomada não duplica nada e nada se perde. Se a ordem mudar, é só na retomada.
    """
    por_id = {str(m["id"]): m for m in atuais}
    manter: set[str] = set()
    repor: list[dict] = []
    for r in registros:
        original = por_id.get(str(r["id"]))
        if original is not None and _igual_original(original, r):
            manter.add(str(r["id"]))
            continue
        refeito = store.get_config(f"replay:{destino.id}:{r['id']}")
        if refeito is not None and refeito in por_id:
            manter.add(refeito)
            continue
        repor.append(r)
    erros: list[str] = []
    for m in atuais:
        if str(m["id"]) in manter:
            continue
        try:
            await rest.request("DELETE", f"/channels/{destino.id}/messages/{m['id']}")
        except rest.DiscordHTTPError as exc:
            if exc.status != 404 and exc.codigo != 10008:
                erros.append(f"remoção {m['id']}: {exc}")
        except rest.DiscordTransportError as exc:
            erros.append(f"remoção {m['id']}: {exc}")
    enviadas = 0
    for r in repor:
        checar()
        try:
            resposta = await enviar(r)
        except (rest.DiscordHTTPError, rest.DiscordTransportError) as exc:
            erros.append(f"reenvio {r['id']}: {exc}")
            continue
        if not resposta.get("id"):
            raise RuntimeError("Discord não confirmou o ID da mensagem restaurada")
        store.set_config(f"replay:{destino.id}:{r['id']}", str(resposta["id"]))
        enviadas += 1
    return enviadas, erros


async def _renovar_links(registros: list[dict]) -> int:
    """Pede à API links novos para anexos com link expirado e sem arquivo guardado.

    A Discord só devolve link novo para arquivo que ainda existe nos servidores dela. Se o arquivo
    já foi removido, o link continua expirado e a mensagem sai com aviso.
    """
    import time as _tempo

    agora = _tempo.time()
    pendentes = [
        a
        for r in registros
        for a in r.get("anexos") or []
        if a.get("url")
        and not regras.url_valida(a["url"], agora)
        and not (a.get("arquivo") and Path(a["arquivo"]).exists())
    ]
    urls = sorted({a["url"] for a in pendentes})
    if not urls:
        return 0
    trocadas: dict[str, str] = {}
    for i in range(0, len(urls), 50):
        try:
            resposta = await rest.request(
                "POST", "/attachments/refresh-urls", {"attachment_urls": urls[i : i + 50]}
            )
        except (rest.DiscordHTTPError, rest.DiscordTransportError) as exc:
            log.warning("não consegui renovar links de anexos: %s", exc)
            continue
        for item in (resposta.get("refreshed_urls") if isinstance(resposta, dict) else None) or []:
            if item.get("original") and item.get("refreshed"):
                trocadas[item["original"]] = item["refreshed"]
    for a in pendentes:
        if a["url"] in trocadas:
            a["url"] = trocadas[a["url"]]
    return len(trocadas)


async def _destino(guild: discord.Guild, novo: str):
    destino = guild.get_channel(int(novo)) or guild.get_thread(int(novo))
    if destino is None:
        destino = await guild.fetch_channel(int(novo))
    return destino


async def restaurar_snapshot(
    guild: discord.Guild,
    snapshot_dados: dict,
    mapa: dict[str, str],
    *,
    fase: str,
    bot_id: int,
    checar=lambda: None,
) -> dict:
    """fase='proprias': mensagens do próprio bot, enviadas pelo bot (sem webhook).
    fase='membros': mensagens de membros, bots e webhooks, enviadas por webhook.

    Só mexe nas mensagens da fase (a outra fase fica intacta). Nunca apaga o que não está no backup
    do mesmo tipo. Falhas são devolvidas e impedem a conclusão; nada é descartado em silêncio.
    """
    if not snapshot_dados.get("completo"):
        return {"enviadas": 0, "falhas": ["snapshot de mensagens incompleto; mensagens atuais preservadas"]}
    limite = getattr(guild, "filesize_limit", None) or regras.LIMITE_ARQUIVO_PADRAO
    import time as _tempo

    total = 0
    falhas: list[str] = []
    for antigo, registros in snapshot_dados.get("canais", {}).items():
        if mapa.get(f"sem_membros:{antigo}"):
            continue  # thread sem membros: não foi recriada de propósito
        filtrados = [r for r in registros if (str(r["autor"].get("id")) == str(bot_id)) == (fase == "proprias")]
        if not filtrados:
            continue
        novo = mapa.get(str(antigo), str(antigo))
        try:
            destino = await _destino(guild, novo)
        except discord.HTTPException as exc:
            falhas.append(f"canal {antigo} não encontrado: {exc}")
            continue
        arquivada = isinstance(destino, discord.Thread) and destino.archived
        try:
            if arquivada:
                await destino.edit(archived=False, reason="Restaurar mensagens")
            await _renovar_links(filtrados)
            atuais_todas = await _buscar(destino.id, None)
            atuais = [
                m for m in atuais_todas
                if (str((m.get("author") or {}).get("id")) == str(bot_id)) == (fase == "proprias")
            ]

            async def enviar(r, _destino=destino):
                agora = _tempo.time()
                if fase == "proprias":
                    payload, arquivos, v2, avisos = _payload(r, webhook=False, limite=limite, agora=agora)
                    resposta = await _enviar_proprio(_destino, payload, arquivos)
                else:
                    pai = _destino.parent if isinstance(_destino, discord.Thread) else _destino
                    payload, arquivos, v2, avisos = _payload(r, webhook=True, limite=limite, agora=agora)
                    resposta = await _enviar_webhook(pai, _destino, payload, arquivos, v2)
                for aviso in avisos:
                    log.warning("mensagem %s do canal %s: %s", r["id"], antigo, aviso)
                return resposta

            enviadas, erros = await _sincronizar(destino, filtrados, atuais, enviar, checar)
            total += enviadas
            falhas.extend(f"{antigo}: {e}" for e in erros)
        except Pausado:
            raise
        except (rest.DiscordHTTPError, rest.DiscordTransportError, discord.HTTPException, RuntimeError) as exc:
            falhas.append(f"canal {antigo}: {exc}")
        finally:
            if arquivada:
                try:
                    await destino.edit(archived=True, reason="Estado do backup")
                except discord.HTTPException as exc:
                    falhas.append(f"arquivamento {antigo}: {exc}")
    return {"enviadas": total, "falhas": falhas[:50]}


async def _buscar(canal_id: int, cursor: str | None) -> list[dict]:
    """Todas as mensagens do canal. Sem limite de quantidade."""
    saida: list[dict] = []
    antes = None
    while True:
        qs = "?limit=100" + (f"&before={antes}" if antes else "")
        lote = await rest.request("GET", f"/channels/{canal_id}/messages{qs}") or []
        if not isinstance(lote, list) or not lote:
            break
        saida.extend(lote)
        antes = min(int(m["id"]) for m in lote)
        if len(lote) < 100:
            break
    return saida


async def restaurar(guild: discord.Guild, mapa: dict[str, str]) -> int:
    """Compatibilidade com backups antigos (sem snapshot): reenvia o histórico do JSONL nos canais recriados."""
    total = 0
    for antigo, novo in mapa.items():
        if antigo == novo or not _ler_canal(antigo):
            continue
        destino = guild.get_channel(int(novo)) or guild.get_thread(int(novo))
        if destino is None:
            continue
        regs = _ler_canal(antigo)
        for r in regs:
            pai = destino.parent if isinstance(destino, discord.Thread) else destino
            payload, arquivos, v2, _ = _payload(r, webhook=True, limite=regras.LIMITE_ARQUIVO_PADRAO, agora=0)
            try:
                await _enviar_webhook(pai, destino, payload, arquivos, v2)
                total += 1
            except (rest.DiscordHTTPError, rest.DiscordTransportError, discord.HTTPException) as exc:
                log.warning("histórico do canal %s não restaurado: %s", antigo, exc)
    return total
