"""Proteção anti-nuke: snapshot de canais, restauração de canais apagados e lockdown do servidor."""

import asyncio
import logging
import json
import time
from collections import deque

import discord

from ..config import settings
from ..data import store
from ..ui.emojis import E
from ..config.settings import CORES
from . import backup, context, raid, incidente

log = logging.getLogger("antinuke")

_deletes: deque[float] = deque()
_creates: deque[float] = deque()
_lockdown_ativo = False


def ligado() -> bool:
    """Anti-nuke: restauração de canais apagados em massa e lockdown. Desligado, só o anti-raid por autor segue."""
    return raid.flag("antinuke_ativo")


def snapshot_channels(guild: discord.Guild | None) -> None:
    if guild is None or incidente.ativo(guild.id):
        return
    vivos = {str(ch.id) for ch in guild.channels}
    store.drop_snapshots(store.snapshot_ids() - vivos)
    linhas = [linha for linha in map(_linha, guild.channels) if linha is not None]
    store.save_channel_snapshots(linhas)
    log.info("snapshot de %d canais salvo", len(linhas))


def _tipo(channel: discord.abc.GuildChannel) -> str | None:
    if isinstance(channel, discord.TextChannel):
        return "text"
    if isinstance(channel, discord.VoiceChannel):
        return "voice"
    if isinstance(channel, discord.CategoryChannel):
        return "category"
    return None


def _linha(channel: discord.abc.GuildChannel) -> tuple | None:
    tipo = _tipo(channel)
    if tipo is None:
        return None
    return (
        str(channel.id),
        channel.name,
        tipo,
        str(channel.category_id) if channel.category_id else None,
        getattr(channel, "topic", None),
        channel.position,
        json.dumps(backup._overwrites(channel)),
    )


def _save(channel: discord.abc.GuildChannel) -> None:
    linha = _linha(channel)
    if linha is not None:
        store.save_channel_snapshots([linha])


def _count(janela: deque[float], limite: int) -> bool:
    agora = time.monotonic()
    while janela and agora - janela[0] > settings.NUKE_JANELA_S:
        janela.popleft()
    janela.append(agora)
    return len(janela) >= limite


async def _apagar_canal(channel: discord.abc.GuildChannel) -> None:
    try:
        await channel.delete(reason="Anti-raid: criação em massa")
    except discord.HTTPException:
        pass


_bloqueio_ate = 0.0
_acompanhando = False


def _bloqueio_ativo() -> bool:
    return time.monotonic() < _bloqueio_ate


async def _acompanhar_bloqueio(guild: discord.Guild) -> None:
    """Quando ninguém cria canal pelo tempo do bloqueio, o bloqueio termina e isso vai para o log."""
    global _acompanhando
    try:
        while (restante := _bloqueio_ate - time.monotonic()) > 0:
            await asyncio.sleep(restante)
        await raid.log_acesso(
            f"{E.correct} Bloqueio de criação encerrado",
            CORES["info"],
            [
                ("Motivo", f"ninguém criou canal por {settings.NUKE_BLOQUEIO_S} s"),
                ("Servidor", guild.name),
            ],
        )
    finally:
        _acompanhando = False


async def _iniciar_bloqueio(guild: discord.Guild, motivo: str) -> None:
    """Cada canal criado durante o bloqueio renova o prazo. Sem criação por NUKE_BLOQUEIO_S, ele termina."""
    global _bloqueio_ate, _acompanhando
    if not _bloqueio_ativo():
        await raid.log_acesso(
            f"{E.alert} Bloqueio de criação ativado",
            CORES["erro"],
            [
                ("Motivo", motivo),
                ("Servidor", guild.name),
                ("Efeito", "todo canal novo é apagado até a criação parar"),
            ],
        )
    _bloqueio_ate = time.monotonic() + settings.NUKE_BLOQUEIO_S
    if not _acompanhando:
        _acompanhando = True
        asyncio.create_task(_acompanhar_bloqueio(guild))


async def on_channel_created(channel: discord.abc.GuildChannel) -> None:
    guild = channel.guild
    if not (ligado() or raid.ligado() or incidente.ativo(guild.id)):
        _save(channel)
        return
    autor = await raid.autor_recente(
        guild, discord.AuditLogAction.channel_create, channel.id
    )
    if autor is not None and autor.id == raid._bot_id():
        if not incidente.ativo(guild.id):
            _save(channel)
        return
    bot_atacando = raid.ator_bot_externo(autor)
    atingiu = (
        bot_atacando
        or raid.excedeu("channel_create", autor)
        or (ligado() and _count(_creates, settings.NUKE_CREATE_LIMITE))
    )
    if atingiu or incidente.ativo(guild.id):
        await incidente.iniciar(guild, "Criação de canais durante raid")
        if autor and not incidente.dono(guild, autor.id):
            await raid.punir(
                guild, autor.id, "Criação de canais em massa", tirar_cargos=True
            )
        await _apagar_canal(channel)
        return
    _save(channel)


async def on_channel_deleted(channel: discord.abc.GuildChannel) -> None:
    guild = channel.guild
    if not (ligado() or raid.ligado() or incidente.ativo(guild.id)):
        store.pop_channel_snapshot(channel.id)
        return
    autor = await raid.autor_recente(
        guild, discord.AuditLogAction.channel_delete, channel.id
    )
    if autor is not None and autor.id == raid._bot_id():
        return
    bot_atacando = raid.ator_bot_externo(autor)
    atingiu = (
        bot_atacando
        or raid.excedeu("channel_delete", autor)
        or (ligado() and _count(_deletes, settings.NUKE_DELETE_LIMITE))
    )
    if atingiu or incidente.ativo(guild.id):
        await incidente.iniciar(guild, "Exclusão de canais durante raid")
        if autor and not incidente.dono(guild, autor.id):
            await raid.punir(
                guild, autor.id, "Exclusão de canais em massa", tirar_cargos=True
            )
        # Só repõe canais do backup fixado ANTES do ataque, nunca um snapshot contaminado.
        s = incidente.estado(guild.id)
        if s.get("backup"):
            dados = json.loads((backup.PASTA / s["backup"]).read_text(encoding="utf-8"))
            original = next(
                (
                    c
                    for c in dados.get("canais", [])
                    if int(s.get("mapa", {}).get(c["id"], c["id"])) == channel.id
                ),
                None,
            )
            if original:
                await _repor_backup(guild, original, s)


async def _repor_backup(guild, original, estado):
    # A rotina compartilhada suporta também fórum e palco. Sem limpeza de extras aqui.
    dados = {"schema_version": 1, "canais": [original]}
    mapa = dict(estado.get("mapa", {}))
    await backup._canais(guild, dados, mapa)
    estado["mapa"] = mapa
    incidente.salvar(guild.id)


async def _restore(guild: discord.Guild, snap) -> None:
    category = (
        guild.get_channel(int(snap["category_id"])) if snap["category_id"] else None
    )
    try:
        if not snap["permissoes"]:
            log.warning(
                "snapshot legado sem permissões; use o backup completo para %s",
                snap["name"],
            )
            return
        overwrites = backup._permissoes(guild, {}, json.loads(snap["permissoes"]))
        if snap["type"] == "text":
            await guild.create_text_channel(
                name=snap["name"],
                category=category,
                topic=snap["topic"],
                position=snap["position"] or 0,
                overwrites=overwrites,
            )
        elif snap["type"] == "category":
            await guild.create_category(
                name=snap["name"], position=snap["position"] or 0, overwrites=overwrites
            )
        else:
            await guild.create_voice_channel(
                name=snap["name"],
                category=category,
                position=snap["position"] or 0,
                overwrites=overwrites,
            )
        await raid.log_acesso(
            f"{E.correct} Canal restaurado", CORES["info"], [("Canal", snap["name"])]
        )
    except (discord.HTTPException, ValueError) as exc:
        log.warning("falha ao restaurar #%s: %s", snap["name"], exc)
        await raid.log_acesso(
            f"{E.alert} Falha ao restaurar canal",
            CORES["erro"],
            [("Canal", snap["name"]), ("Erro", str(exc)[:200])],
        )


async def _aplicar_everyone(guild: discord.Guild, travar: bool) -> None:
    everyone = guild.default_role
    limite = asyncio.Semaphore(5)

    async def um(channel: discord.abc.GuildChannel) -> None:
        async with limite:
            try:
                overwrite = channel.overwrites_for(everyone)
                key = f"nuke_lock:{guild.id}:{channel.id}"
                if travar:
                    if store.get_config(key) is None:
                        allow, deny = overwrite.pair()
                        store.set_config(key, json.dumps([allow.value, deny.value]))
                    overwrite.send_messages = False
                    overwrite.connect = False
                else:
                    saved = store.get_config(key)
                    if saved is None:
                        return
                    allow, deny = json.loads(saved)
                    overwrite = discord.PermissionOverwrite.from_pair(
                        discord.Permissions(allow), discord.Permissions(deny)
                    )
                await channel.set_permissions(
                    everyone, overwrite=None if overwrite.is_empty() else overwrite
                )
                if not travar:
                    store.reset_config(key)
            except discord.HTTPException:
                pass

    canais = [*guild.text_channels, *guild.voice_channels]
    await asyncio.gather(*(um(c) for c in canais))


async def lockdown(guild: discord.Guild, motivo: str) -> None:
    global _lockdown_ativo
    if _lockdown_ativo:
        return
    _lockdown_ativo = True
    await _aplicar_everyone(guild, True)
    try:
        dono = await context.user(settings.ADMIN_ID)
        await dono.send(
            f"{E.alert} **ANTI-NUKE ATIVADO**\nMotivo: `{motivo}`\nServer: `{guild.name}`\n\n"
            f"Use `>reverter` no privado para desfazer o lockdown."
        )
    except discord.HTTPException:
        pass


async def revert(guild: discord.Guild) -> None:
    global _lockdown_ativo
    await _aplicar_everyone(guild, False)
    _lockdown_ativo = False


def lockdown_active() -> bool:
    return _lockdown_ativo or any(
        k.startswith("nuke_lock:") for k in store.todas_configs()
    )
